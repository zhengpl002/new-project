import Vue from 'vue'
import Router from 'vue-router'
const _import = require('./_import_' + process.env.NODE_ENV);
/*投保向导*/
const guide = _import('insure/guide/index');
const added = _import('insure/added/index');
const userView = _import('insure/added/userView/index')

Vue.use(Router)

export default new Router({
	routes: [
		{
			path: '/insure/guide',
			name: "投保向导",
			component: guide,
		},
		{
			path: '/insure/added',
			name: "新增投保",
			component: added,
			meta: {
				keepAlive: true,
			}
		},
		{
			path: '/insure/added/userView',
			name: "客户视图",
			component: userView
		}
	]
})




