module.exports = file => require('@/components/' + file + '.vue')
