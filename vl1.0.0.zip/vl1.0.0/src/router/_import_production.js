module.exports = file => () => import('@/components/' + file + '.vue')
