const Insured = {
  state: {
    insuredData: {
      /* 表单数据 */
      userCode: '',
      userName: '',
      naturePolicyholder: '',
      certificatesType: '',
      certificatesCode: '',
      effective: '',
      occupation: '',
      sex: '',
      shareholderUser: 1,
      country: '',
      province: '',
      city: '',
      area: '',
      street: '',
      address: '',
      zipCode: '',
      level: '',
      reason: '',
      managingContacts: '',
      unitProperties: '',
      agentCard: '',
      agentCardDate: '',
      fixedTelephone: '',
      moveTelephone: '',
      fax: '',
      legalRepresentative: '',
      legalRepresentativeCode: '',
      legalRepresentativeDate: '',
      organizationCodeCertificate: '',
      taxRegistrationCertificate: '',
      businessLicence: '',
      /* 表单数据 */
    }
  },

  mutations: {
    SET_INSURED_DATA: (state, newState) => {
      state.insuredData = newState
    }
  },

  actions: {},

  getters: {
    getInsured: state => state.insuredData
  }
}

export default Insured