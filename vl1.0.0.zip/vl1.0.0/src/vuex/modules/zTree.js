import {Message} from 'element-ui';
import {getDeptTree} from '../../public/js/httpRequest';
import {recursive} from './../../public/js/public';
/*业务来源*/
const zTree = {
        state: {
            isFirst: true,
            tree: [],
            isShowTree: false,
        },
        mutations: {
            SET_ZTREE_TREE(state, newState) {
                state.tree = newState;
            },
            SET_ZTREE_ISFIRSE(state, newState) {
                state.isFirst = newState;
            },
            SET_ZTREE_ISSHOWTREE(state, newState) {
                state.isShowTree = newState;}
        },

        actions: {
            /*获取机构树*/
            getZtree({commit, state}, product) {
                if (state.isFirst) {
                    /*    const user=JSON.parse(window.sessionStorage.getItem('user'));
                        const cDptCde=user.currentDep;*/
                    const cDptCde = '10';
                    const call = function (res) {
                        commit('SET_ZTREE_ISFIRSE', false);
                        const list = res.data;
                        commit('SET_ZTREE_TREE', list);
                        if (list.length) {
                            const code = res.data[0].cDptCde;
                            const name = res.data[0].cDptAbr;
                            commit(`SET_TEAMMANAGE_DEPNAME`, `${code}_${name}`);
                            commit(`SET_PERSONNELMANAGE_DEPNAME`, `${code}_${name}`);
                            commit(`SET_TEAMMANAGE_DEP`, code);
                            commit(`SET_PERSONNELMANAGE_DEP`, code);
                            if (6 == list[0].cDptCde.length) {
                                commit(`SET_ADDTEAM_DEPNAME`, `${code}_${name}`);
                                commit(`SET_ADDTEAM_DEP`, code);
                            }
                        }
                    }
                    getDeptTree({cDptCde}, call)
                }

            }
        },
    }
;
export default zTree;
