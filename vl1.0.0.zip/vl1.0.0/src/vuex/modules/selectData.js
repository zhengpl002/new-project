const SelectData = {
  state: {
    naturePolicy: [
      { name: '非自然人', value: 1, key: 1, },
      { name: '自然人', value: 2, key: 2, },
    ],
    certificates: [
      { name: '税务登记证', value: 1, key: 1, },
      { name: '组织机构代码证', value: 2, key: 2, },
      { name: '工商注册号码', value: 3, key: 3, },
      { name: '营业执照', value: 4, key: 4, },
      { name: '三证合一', value: 5, key: 5, },
      { name: '其他', value: 6, key: 6, },
      { name: '居民身份证', value: 7, key: 7, },
      { name: '护照', value: 8, key: 8, },
      { name: '军人证', value: 9, key: 9, },
      { name: '外国人永久居留身份证', value: 10, key: 10, },
      { name: '其它', value: 11, key: 11, },
      { name: '港澳通行证', value: 12, key: 12, },
      { name: '台胞证', value: 13, key: 13, },
    ],
    selectSex: [
      { name: '男', value: 1, key: 1, },
      { name: '女', value: 2, key: 2, },
    ],
    shareholder: [
      { name: '否', value: 1, key: 1, },
      { name: '是', value: 2, key: 2, },
    ],
    testData: [
      { name: '测试1', value: 1, key: 1, },
      { name: '测试2', value: 2, key: 2, },
      { name: '测试3', value: 3, key: 3, },
      { name: '测试4', value: 4, key: 4, },
    ],
    levelArr: [
      { name: '高风险', value: 1, key: 1, },
      { name: '待评估', value: 2, key: 2, },
    ],
    reasonArr: [],
    riskArr: [
      { name: '虚假证件', value: 1, key: 1, },
      { name: '政治公众人物', value: 2, key: 2, },
      { name: '金融违规记录', value: 3, key: 3, },
      { name: '监管机构提示关注', value: 4, key: 4, },
      { name: '洗钱类负面报道', value: 5, key: 5, },
      { name: '反洗钱监控地区', value: 6, key: 6, },
      { name: '拒绝开展尽职调查', value: 7, key: 7, },
      { name: '可疑情形', value: 8, key: 8, },
    ],
    waitArr: [
      { name: '待评估', value: 1, key: 1, },
    ],
    taxpayerAptitude: [],
    invoiceTypeArr: [],
    invoiceMediumArr: [],
  },

  getters: {
    getSelectData: state => state
  },
}

export default SelectData