const Save = {
  state: {
    saveData: {},
  },

  mutations: {
    SET_SAVE_DATA: (state, newState) => {
      state.saveData = newState
    }
  },

  actions: {},
  
  getters: {
    getSaveData: state => state.saveData,
  },
}

export default Save