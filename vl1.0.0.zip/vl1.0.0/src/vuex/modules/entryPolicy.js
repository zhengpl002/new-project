import {Message} from 'element-ui';


/*保单查询*/
const entryPolicy = {
        /*初始状态*/
        state: {},
        /*对初始状态的值进行同步操作,按照官方建议方法名全部为大写*/
        mutations: {},
        /*对初始状态的值进行异步操作，比如ajax请求，方法名全部为大写*/
        actions: {},
    }
;
export default entryPolicy;
