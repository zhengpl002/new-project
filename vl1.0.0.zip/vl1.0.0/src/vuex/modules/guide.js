import {Message} from 'element-ui';
import {getDeptTree} from './../../public/js/httpRequest';
import {FormatToTimestamp} from './../../public/js/public';


/*保单查询*/
const entryPolicy = {
        /*初始状态*/
        state: {
            query:{
                cUagency: '',/*承保机构*/
                cProduct: '1',/*产品*/
                cProductt: '',/*产品*/
                cInbus: '1',/*共保业务*/
                cDivbus: '2',/*分入业务*/
                cWheade: '2',/*是否涉水*/
                cRelist: '2',/*团单*/
                cDrain: '2',/*涉农标志*/
            }
        },
        /*对初始状态的值进行同步操作,按照官方建议方法名全部为大写*/
        mutations: {
            /*查询结构*/
            SET_QUERY(state,newState){
                state.result=newState;
            },
        },
        /*对初始状态的值进行异步操作，比如ajax请求，方法名全部为大写*/
        actions: {
            getQuery({commit,state}){
              let data=state.query.cUagency;
              const call=function (res) {
                  commit('SET_QUERY',res.data.list);
              }
              getDeptTree(data,call)
          }
        },
    }
;
export default entryPolicy;
