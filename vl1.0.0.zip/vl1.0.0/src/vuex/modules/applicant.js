/* 投保信息 */
const Applicant = {
  state: {
    applicantData: {
      /* 表单数据 */
      userCode: '',
      userName: '',
      naturePolicyholder: '',
      certificatesType: '',
      certificatesCode: '',
      effective: '',
      occupation: '',
      sex: '',
      shareholderUser: 1,
      country: '',
      province: '',
      city: '',
      area: '',
      street: '',
      address: '',
      zipCode: '',
      level: '',
      reason: '',
      managingContacts: '',
      fixedTelephone: '',
      moveTelephone: '',
      fax: '',
      Email: '',
      taxpayerAptitude: '',
      bankAccount: '',
      openingBank: '',
      invoiceType: '',
      taxpayerCode: '',
      invoiceMedium: '',
      drawBillTel: '',
      drawBillAddress: '',
    /* 表单数据 */
    }
  },

  mutations: {
    SET_APPLICANT_DATA: (state, newState) => {
      state.applicantData = newState
    }
  },

  actions: {},

  getters: {
    getApplicant: state => state.applicantData
  }
}

export default Applicant