const UnderWriting = {
  state: {
    // underWriting: {},

    /* 测试数据 */
    underWriting: {
      name: '境内旅游意外伤害保险',
      id: 100001,
      list: [
        {
          name: '限制规则',
          type: 'form',
          show: true,
          children: [
            {
              label: '免赔方式', type: 'select', model: 'type', disable: false, must: 2, selectData: [
                { value: 1, label: '绝对免赔' },
                { value: 2, label: '相对免赔' },
              ],
            },
            {
              label: '免赔额', type: 'input', model: 'name', disable: true, must: 1, valid: 'string', trigger: 'blur', message: '请输入名字'
            },
            {
              label: '免赔率', type: 'input', model: 'tate', disable: true, must: 1, valid: 'number', trigger: 'blur', message: '请输入年龄'
            },
            {
              label: '免赔说明', type: 'input', model: 'explain', disable: false, must: 2
            },
            {
              label: '是否已询价', type: 'select', model: 'inquiry', default: 2, disable: false, must: 2, selectData: [
                { value: 1, label: '是' },
                { value: 2, label: '否' },
              ],
            },
            {
              label: '免赔说明', type: 'input', model: 'explain', disable: false, must: 2
            },
          ],
        },
        {
          name: '表单1号',
          type: 'form',
          show: true,
          children: [
            {
              label: '姓名', type: 'input', model: 'name', disable: false, must: 1, valid: 'string', trigger: 'blur', message: '请输入名字'
            },
            {
              label: '年龄', type: 'input', model: 'age', disable: false, must: 1, valid: 'number', trigger: 'blur', message: '请输入年龄', length: 3
            },
            {
              label: '职业', type: 'select', model: 'vocation', disable: true, must: 2, selectData: [
                { value: 10001, label: '职业一' },
                { value: 10002, label: '职业二' },
                { value: 10003, label: '职业三' },
                { value: 10004, label: '职业四' },
              ],
            }
          ],
        },
        {
          name: '表单2号',
          type: 'form',
          show: true,
          children: [
            {
              label: 'aa', type: 'select', model: 'test1', disable: false, must: 2, selectData: [
                { value: 10001, label: '选项一' },
                { value: 10002, label: '选项二' },
                { value: 10003, label: '选项三' },
                { value: 10004, label: '选项四' },
              ],
            },
            {
              label: 'bb', type: 'select', model: 'test2', disable: false, must: 1, valid: 'number', trigger: 'change', message: '虽然不知道这个是啥,但这个也是必填的', selectData: [
                { value: 10001, label: '选项一' },
                { value: 10002, label: '选项二' },
                { value: 10003, label: '选项三' },
                { value: 10004, label: '选项四' },
              ],
            },
            {
              label: 'aa', type: 'select', model: 'newName', disable: false, must: 2, selectData: [
                { value: 10001, label: '选项一' },
                { value: 10002, label: '选项二' },
                { value: 10003, label: '选项三' },
                { value: 10004, label: '选项四' },
              ],
            },
            {
              label: 'aa', type: 'select', model: 'newName2', disable: false, must: 2, selectData: [
                { value: 10001, label: '选项一' },
                { value: 10002, label: '选项二' },
                { value: 10003, label: '选项三' },
                { value: 10004, label: '选项四' },
              ],
            },
            {
              label: 'aa', type: 'select', model: 'newName3', disable: false, must: 2, selectData: [
                { value: 10001, label: '选项一' },
                { value: 10002, label: '选项二' },
                { value: 10003, label: '选项三' },
                { value: 10004, label: '选项四' },
              ],
            },
            {
              label: 'aa', type: 'select', model: 'newName4', disable: false, must: 2, selectData: [
                { value: 10001, label: '选项一' },
                { value: 10002, label: '选项二' },
                { value: 10003, label: '选项三' },
                { value: 10004, label: '选项四' },
              ],
            },
          ],
        },
        {
          name: '险别信息',
          /* 一键清空 */
          /* additional: true, */
          check: true,
          type: 'table',
          show: true,
          children: [
            {
              label: '方案号', value: 'planCode', type: 'input', model: 'planCode', disable: true
            },
            {
              label: '险别名称', value: 'riskName', width: 400, type: 'input', model: 'riskName', disable: true
            },
            {
              label: '保险责任', value: 'insuranceLiability', type: 'input', model: 'insuranceLiability', disable: true
            },
            {
              label: '每日津贴金额', value: 'allowance', type: 'input', model: 'allowance', disable: true, valid: 'number'
            },
            {
              label: '每人保额', value: 'coverage', type: 'input', model: 'coverage', disable: false, valid: 'number', length: 10000
            },
            {
              label: '投保人数', value: 'num', type: 'input', model: 'num', disable: false, valid: 'number', length: ''
            },
            {
              label: '保险金额/限额', value: 'quota', type: 'input', model: 'quota', disable: true, valid: 'number'
            },
            {
              label: '基准费率（%）', value: 'rateBase', type: 'input', model: 'rateBase', disable: true
            },
            {
              label: '折扣系数', value: 'agio', type: 'input', model: 'agio', disable: false
            },
            {
              label: '含税保费', value: 'tax', type: 'input', model: 'tax', disable: true
            },
            {
              label: '不含税保费', value: 'intax', type: 'input', model: 'intax', disable: true
            },
            {
              label: '税额', value: 'taxAmount', type: 'input', model: 'amount', disable: true
            },
            {
              label: '备注', value: 'desc', type: 'input', model: 'desc', disable: false
            },
          ],
          tableList: [],
          // tableList: [
          //   { id: 60171, planCode: 'P1', riskName: '060171 境内旅游意外伤害', insuranceLiability: '意外身故、伤残', allowance: '', coverage: '', num: '', quota: '', rateBase: 1.00, agio: 100, tax: 0.00, intax: 0.00, taxAmount: 0.00, desc: '' },
          //   { id: 60157, planCode: 'P1', riskName: '060157 附加高风险运动意外伤害保险条款', insuranceLiability: '高风险运动意外旅行', allowance: '', coverage: '', num: '', quota: '', rateBase: 0, agio: 100, tax: 0.00, intax: 0.00, taxAmount: 0.00, desc: '' },
          //   { id: 60172, planCode: 'P1', riskName: '060172 境内旅行附加住院津贴保险条款', insuranceLiability: '住院津贴', allowance: '', coverage: '', num: '', quota: '', rateBase: 1.00, agio: 100, tax: 0.00, intax: 0.00, taxAmount: 0.00, desc: '' },
          //   { id: 60173, planCode: 'P1', riskName: '060173 境内旅行附加旅程延误保险条款', insuranceLiability: '旅程延误', allowance: '', coverage: '', num: '', quota: '', rateBase: 15.00, agio: 100, tax: 0.00, intax: 0.00, taxAmount: 0.00, desc: '' },
          //   { id: 60174, planCode: 'P1', riskName: '060174 附加第三者责任保险条款', insuranceLiability: '第三者责任', allowance: '', coverage: '', num: '', quota: '', rateBase: 1.50, agio: 100, tax: 0.00, intax: 0.00, taxAmount: 0.00, desc: '' },
          //   { id: 60175, planCode: 'P1', riskName: '060175 附加意外伤害医疗保险条款', insuranceLiability: '意外伤害医疗', allowance: '', coverage: '', num: '', quota: '', rateBase: 8.00, agio: 100, tax: 0.00, intax: 0.00, taxAmount: 0.00, desc: '' },
          //   { id: 60176, planCode: 'P1', riskName: '060176 附加旅程取消保险条款', insuranceLiability: '旅程取消', allowance: '', coverage: '', num: '', quota: '', rateBase: 1.50, agio: 100, tax: 0.00, intax: 0.00, taxAmount: 0.00, desc: '' },
          //   { id: 60177, planCode: 'P1', riskName: '060177 附加急性病医疗保险条款', insuranceLiability: '急性病医疗', allowance: '', coverage: '', num: '', quota: '', rateBase: 0, agio: 100, tax: 0.00, intax: 0.00, taxAmount: 0.00, desc: '' },
          //   { id: 60178, planCode: 'P1', riskName: '060178 附加急性病身故保险条款', insuranceLiability: '急性病身故', allowance: '', coverage: '', num: '', quota: '', rateBase: 0, agio: 100, tax: 0.00, intax: 0.00, taxAmount: 0.00, desc: '' },
          //   { id: 60179, planCode: 'P1', riskName: '060179 附加绑架及非法拘禁保险条款', insuranceLiability: '绑架及非法拘禁', allowance: '', coverage: '', num: '', quota: '', rateBase: 3.00, agio: 100, tax: 0.00, intax: 0.00, taxAmount: 0.00, desc: '' },
          // ],
        }
      ],
    },
  },

  mutations: {
    SET_UNDERWRITING_DATA(state, newState) {
      state.underWriting.list = newState
    }
  },

  actions: {},

  getters: {
    getUnderWriting: state => state.underWriting,
  },
}

export default UnderWriting