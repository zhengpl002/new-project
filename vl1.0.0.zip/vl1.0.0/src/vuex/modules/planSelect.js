const Plan = {
  state: {
    planList: [
      { id: 60171, vId: '060171', zId: '062060', planCode: 'P', tpl: '境内旅游意外伤害', riskName: '060171 境内旅游意外伤害', insuranceLiability: '意外身故、伤残', allowance: '', coverage: '', num: '', quota: '', rateBase: 1.00, agio: 100, tax: 0.00, intax: 0.00, taxAmount: 0.00, desc: '' },
      { id: 60157, vId: '060157', zId: '062065', planCode: 'P', tpl: '附加高风险运动意外伤害保险条款', riskName: '060157 附加高风险运动意外伤害保险条款', insuranceLiability: '高风险运动意外旅行', allowance: '', coverage: '', num: '', quota: '', rateBase: 0, agio: 100, tax: 0.00, intax: 0.00, taxAmount: 0.00, desc: '' },
      { id: 60172, vId: '060172', zId: '060006', planCode: 'P', tpl: '境内旅行附加住院津贴保险条款', riskName: '060172 境内旅行附加住院津贴保险条款', insuranceLiability: '住院津贴', allowance: '', coverage: '', num: '', quota: '', rateBase: 1.00, agio: 100, tax: 0.00, intax: 0.00, taxAmount: 0.00, desc: '' },
      { id: 60173, vId: '060173', zId: '062062', planCode: 'P', tpl: '境内旅行附加旅程延误保险条款', riskName: '060173 境内旅行附加旅程延误保险条款', insuranceLiability: '旅程延误', allowance: '', coverage: '', num: '', quota: '', rateBase: 15.00, agio: 100, tax: 0.00, intax: 0.00, taxAmount: 0.00, desc: '' },
      { id: 60174, vId: '060174', zId: '040015', planCode: 'P', tpl: '附加第三者责任保险条款', riskName: '060174 附加第三者责任保险条款', insuranceLiability: '第三者责任', allowance: '', coverage: '', num: '', quota: '', rateBase: 1.50, agio: 100, tax: 0.00, intax: 0.00, taxAmount: 0.00, desc: '' },
      { id: 60175, vId: '060175', zId: '062068', planCode: 'P', tpl: '附加意外伤害医疗保险条款', riskName: '060175 附加意外伤害医疗保险条款', insuranceLiability: '意外伤害医疗', allowance: '', coverage: '', num: '', quota: '', rateBase: 8.00, agio: 100, tax: 0.00, intax: 0.00, taxAmount: 0.00, desc: '' },
      { id: 60176, vId: '060176', zId: '062069', planCode: 'P', tpl: '附加旅程取消保险条款', riskName: '060176 附加旅程取消保险条款', insuranceLiability: '旅程取消', allowance: '', coverage: '', num: '', quota: '', rateBase: 1.50, agio: 100, tax: 0.00, intax: 0.00, taxAmount: 0.00, desc: '' },
      { id: 60177, vId: '060177', zId: '062070', planCode: 'P', tpl: '附加急性病医疗保险条款', riskName: '060177 附加急性病医疗保险条款', insuranceLiability: '急性病医疗', allowance: '', coverage: '', num: '', quota: '', rateBase: 0, agio: 100, tax: 0.00, intax: 0.00, taxAmount: 0.00, desc: '' },
      { id: 60178, vId: '060178', zId: '062071', planCode: 'P', tpl: '附加急性病身故保险条款', riskName: '060178 附加急性病身故保险条款', insuranceLiability: '急性病身故', allowance: '', coverage: '', num: '', quota: '', rateBase: 0, agio: 100, tax: 0.00, intax: 0.00, taxAmount: 0.00, desc: '' },
      { id: 60179, vId: '060179', zId: '062072', planCode: 'P', tpl: '附加绑架及非法拘禁保险条款', riskName: '060179 附加绑架及非法拘禁保险条款', insuranceLiability: '绑架及非法拘禁', allowance: '', coverage: '', num: '', quota: '', rateBase: 3.00, agio: 100, tax: 0.00, intax: 0.00, taxAmount: 0.00, desc: '' },
    ],
    planSelect: [
      { label: '险别编码', value: 'vId', width: 200 },
      { label: '险别名称', value: 'tpl' },
      { label: '责任编码', value: 'zId', width: 200 },
      { label: '责任名称', value: 'insuranceLiability' },
    ]
  },

  mutations: {},

  actions: {},
  
  getters: {
    getPlanList: state => state.planList,
    getPlanSelect: state => state.planSelect,
  },
}

export default Plan