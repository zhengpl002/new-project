import Vue from 'vue';
import Vuex from 'vuex';
/*出行宝*/

/*保单查询*/
import guide from '../components/insure/guide/index';
// import policyInquiry from './modules/policyInquiry';
// import entryPolicy from './modules/entryPolicy';
// import policyInfoDetail from './modules/policyInfoDetail';
import getters from './getters';

/* 国家数据 */
import Country from './modules/country'

/* 保存数据 */
import SaveData from './modules/saveData'
import SelectData from './modules/selectData'
import UnderWriting from './modules/underWriting'
import PlanSelect from './modules/planSelect'
/* 投保信息 */
import Applicant from './modules/applicant'
import Insured from './modules/insured'

Vue.use(Vuex);

const store = new Vuex.Store({
    modules: {
        SaveData,
        Applicant,
        Insured,
        guide,
        SelectData,
        UnderWriting,
        PlanSelect,
        Country,
        // policyInquiry,
        // entryPolicy,
        // policyInfoDetail,
    },
    // getters,
});

export default store;
