const getters = {
    /*保单查询*/
    guide: state => state.guide,
};
export default getters;
