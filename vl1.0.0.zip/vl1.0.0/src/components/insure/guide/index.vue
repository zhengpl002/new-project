<template>
    <div class="teamQuery container">
        <ul class="form">
            <li>
                <span class="label">
                    <i class="red">*</i>承保部门：</span>
                <el-select v-model="query.cUagency" placeholder="请选择承保部门">
                    <el-option v-for="item in cUagency" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                </el-select>
            </li>
        </ul>
             <ul class="form">
            <li>
                <span class="label">
                    <i class="red">*</i>产品：</span>
                <el-select v-model="query.cProduct" placeholder="请选择产品">
                    <el-option v-for="item in cProduct" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                </el-select>
                <el-select v-model="query.cProductt" placeholder="请选择产品" @change="selectProduct()">
                    <el-option v-for="item in cProductt" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                </el-select>
            </li>
             </ul>
             <ul class="form">
            <li>
                <span class="label">共保业务：</span>
                <el-select v-model="query.cInbus" placeholder="请选择">
                    <el-option v-for="item in cInbus" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                </el-select>
            </li>
            <li>
                <span class="label">分入业务：</span>
                <el-select v-model="query.cDivbus" placeholder="请选择">
                    <el-option v-for="item in cDivbus" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                </el-select>
            </li>
            <li>
                <span class="label">涉农标志：</span>
                <el-select v-model="query.cDrain" placeholder="请选择">
                    <el-option v-for="item in cDrain" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                </el-select>
            </li>
            <li>
                <span class="label">是否涉水\涉海：</span>
                <el-select v-model="query.cWheade" placeholder="请选择">
                    <el-option v-for="item in cWheade" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                </el-select>
            </li>
            <li>
                <span class="label">团单：</span>
                <el-select v-model="query.cRelist" placeholder="请选择">
                    <el-option v-for="item in cRelist" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                </el-select>
            </li>
            
        </ul>
        <div class="btn">
            <span class="inquire" @click="confirm">确认</span>
        </div>
    </div>
</template>

<script>
    import { Message } from 'element-ui';
    import { isChinese, FormatToTimestamp, checkDecimal, checkChinese } from './../../../public/js/public';
    import { getProduct, tempConfirm } from './../../../public/js/httpRequest';
    export default {
        data() {
            return {
                nApplyId: '',
                disabled: false,
                cInbus: [
                    { label: '请选择', value: null },
                    { label: '非共保业务', value: '1' },
                    { label: '外部共保（我方主共）', value: '2' },
                    { label: '外部共保（我方从共）', value: '3' },
                ],
                cUagency: [],/*承保机构*/
                cProduct: [
                    { label: '请选择', value: null },
                    { label: '01 企业财产险', value: '1' },
                    { label: '02 货物运输险', value: '2' },
                    { label: '08 家庭财产险', value: '8' },
                    { label: '07 短期健康保险', value: '7' },
                    { label: '06 意外伤害保险', value: '6' },
                    { label: '04 责任险', value: '4' },
                    { label: '09 工程险', value: '9' },
                    { label: '11 船舶保险', value: '11' },
                    { label: '05 保证险', value: '5' },
                ],/*产品*/
                cProductt: [],/*产品*/
                cDivbus: [
                    { label: '请选择', value: null },
                    { label: '是', value: '1' },
                    { label: '否', value: '2' },
                ],/*分入业务*/
                cWheade: [
                    { label: '请选择', value: null },
                    { label: '是', value: '1' },
                    { label: '否', value: '2' },
                ],/*是否涉水*/
                cRelist: [
                    { label: '请选择', value: null },
                    { label: '是', value: '1' },
                    { label: '否', value: '2' },
                ],/*团单*/
                cDrain: [
                    { label: '请选择', value: null },
                    { label: '涉农', value: '1' },
                    { label: '非涉农', value: '2' },
                ],/*涉农标志*/
                query: {
                    cUagency: '',/*承保机构*/
                    cProduct: '1',/*产品*/
                    cProductt: '',/*产品*/
                    cInbus: '1',/*共保业务*/
                    cDivbus: '2',/*分入业务*/
                    cWheade: '2',/*是否涉水*/
                    cRelist: '2',/*团单*/
                    cDrain: '2',/*涉农标志*/

                },
                border1: { border: '1px solid #409eff' },
                border2: { border: '1px solid #d8dce5' },
                style1: { transform: 'rotateZ(135deg)' },
                style2: { transform: 'rotateZ(-45deg)', top: '10px' },
            }
        },
        components: {},
        mounted() {
            // 默认加载承保机构
            this.$nextTick(function () {
                this.$store.dispatch('getQuery');
            })

        },
        methods: {
            // 根据产品选择产品详情
            selectMajor: function () {
                const self = this;
                this.query.cProductt = null
                getProduct(self.query.cProductt, call);
                const call = function (res) {
                    self.cProductt = res.data;
                }
            },
            //确认
            confirm() {
                const query = this.query;
                const data = {
                    deptInfo: query
                }
                const call = function (res) {
                    this.nApplyId = res.data.nApplyId;
                }
                tempConfirm(data, call)
                this.$router.push({ path: `/agencymanage`, query: { nApplyId } });
            },

        },
    }


</script>
<style lang="less">
    @import "../../../less/public.less";
    .container {
        position: relative;
        width: 100%;
        padding-top: 10px;
        box-sizing: border-box;
        background: @form-bg;
        overflow: hidden;
        .form {
            width: 100%;
            display: block;
            overflow: hidden;
            .red {
                position: relative;
                top: 2px;
                left: -6px;
                color: red;
            }
            .date {
                .el-input__prefix {
                    top: -6px;
                }
            }

            li {
                font-size: @min-fontSize;
                color: @fontColor;
                float: left;
                margin-left: 20px;
                margin-bottom: 6px;
                /*    input::-webkit-input-placeholder {
                    color: @placeholderColor;
                }
                input::-moz-placeholder { !* Mozilla Firefox 19+ *!
                    color: @placeholderColor;
                }
                input:-moz-placeholder { !* Mozilla Firefox 4 to 18 *!
                    color: @placeholderColor;
                }
                input:-ms-input-placeholder { !* Internet Explorer 10-11 *!
                    color: @placeholderColor;
                }*/
                .el-input {
                    width: @input-width;
                    font-size: @min-fontSize;
                    color: @fontColor;
                    .el-input__inner {
                        height: @input-height;
                    }
                }
                .label {
                    display: inline-block;
                    width: 108px;
                    text-align: right;
                    float: left;
                    margin-top: 4px;
                }
                .teamDiv {
                    float: left;
                    width: @input-width; //height: @input-height;
                    line-height: 26px;
                    height: 26px;
                    box-sizing: border-box;
                    border: 1px solid #d8dce5;
                    border-radius: 4px;
                    color: #5a5e66;
                    padding: 0 15px;
                    background: #fff;
                }
            }

            .tree {
                position: absolute;
                left: 128px;
                top: 37px;
                z-index: 4;
                width: @input-width;
            }
            .agencyCode {
                position: relative;
                display: inline-block;
                float: left;
                width: @input-width;
                height: 26px;
                border: 1px solid #dcdfe6;
                border-radius: 4px;
                background: #fff;
                font-size: @min-fontSize;
                padding-left: 15px;
                box-sizing: border-box;
                line-height: 26px;
                cursor: pointer;
            }
            .font {
                position: absolute;
                right: 15px;
                top: 5px;
                display: inline-block;
                width: @fontWidth;
                height: @fontWidth;
                transform: rotateZ(135deg);
                border-right: 1px solid #b4bccc;
                border-top: 1px solid #b4bccc;
                transition: all .3s;
            }

        }
        .font {
            position: absolute;
            right: 15px;
            top: 5px;
            display: inline-block;
            width: @fontWidth;
            height: @fontWidth;
            transform: rotateZ(135deg);
            border-right: 1px solid #b4bccc;
            border-top: 1px solid #b4bccc;
            transition: all .3s;
        }
    }

    .btn {
        text-align: right;
        padding-bottom: 6px;
        background: @form-bg;
        span {
            display: inline-block;
            width: 100px;
            font-size: @min-fontSize;
            line-height: 26px;
            border-radius: 26px;
            cursor: pointer;
            margin: 0 10px;
            text-align: center;
        }
        .inquire {
            color: @title-bg;
            border: 1px solid @title-bg;
            &:hover {
                color: #fff;
                background: @title-bg;
            }
        }
    }
</style>