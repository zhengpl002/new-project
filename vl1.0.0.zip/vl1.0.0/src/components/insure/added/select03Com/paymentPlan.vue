<template>
  <Fold Name="缴费计划" @Switch-form="show = !show">
    <section v-if="show"></section>
  </Fold>
</template>

<script>
  import Fold from 'utils/fold/fold'
  export default {
    name: "paymentPlan",
  
    components: {
      Fold,
    },
    
    data() {
      return {
        show: true,
      }
    },
  
    watch: {},
  
    computed: {},
  
    methods: {},
  
    created() {},
  
    mounted() {},
  
  }
</script>

<style lang="less" scoped>

</style>