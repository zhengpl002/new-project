export function type(table, data, id, row){
  let dataList = data
  if(id === 100001) dataList = insurance.travelAccidentInsurance(table, data, row)
  return dataList
}

const insurance = {
  /* 境内旅游意外伤害保险 */
  travelAccidentInsurance(table, data, row) {
      /* 处理方案组 */
    for(let item of table) {
      item.planCode === data.planCode ? item.num = data.num : ''
      item.coverage !== '' ? item.quota = parseInt(item.coverage) * parseInt(item.num) : ''
    }

    data.allowance !== '' ? data.coverage = parseInt(data.allowance) / 10 * 1800 : ''
    data.quota = parseInt(data.coverage) * parseInt(data.num) || ''
    return data
  }
}
