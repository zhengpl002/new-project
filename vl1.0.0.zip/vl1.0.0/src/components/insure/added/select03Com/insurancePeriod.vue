<template>
  <Fold Name="保险期限" @switch-form="show = !show">
    <section v-if="show">
      <el-form inline>
        <el-form-item label="保险起止期：" prop="date">
          <el-date-picker @change="sum" v-model="date" type="datetimerange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期">
          </el-date-picker>
        </el-form-item>
        <el-form-item label="共">
          <el-input v-model="sumDate" disabled></el-input>
        </el-form-item>
        <el-form-item label="天">
        </el-form-item>
      </el-form>
    </section>
  </Fold>
</template>

<script>
  import Fold from 'utils/fold/fold'
  export default {
    name: "insurancePeriod",

    components: {
      Fold,
    },

    data() {
      return {
        show: true,
        sumDate: '',
        year: new Date().getFullYear(),
        month: new Date().getMonth(),
        day: new Date().getDate(),
        date: [],

        /* 表单校验 */
        rules: [],
        /* 表单校验 */
      }
    },

    watch: {},

    computed: {
    },

    methods: {
      /* 计算时间戳 */
      sum(val) {
        if(val && val.length === 2) {
          this.sumDate = Math.round((Number(val[1]) - Number(val[0])) / 1000 / 60 / 60 / 24)
        } else {
          this.sumDate = ''
        }
      },
    },

    created() {
      /* 初始统计1年, 365天 (闰年366天) */
      let oldDate = new Date(this.year, this.month, this.day + 1, 0, 0)
      let newDate = new Date(this.year + 1, this.month, this.day, 23, 59, 59)
      this.date.push(oldDate)
      this.date.push(newDate)
      this.sumDate = Math.round((newDate - oldDate) / 1000 / 60 / 60 / 24)
    },

    mounted() { },

  }
</script>

<style lang="less" scoped>
</style>