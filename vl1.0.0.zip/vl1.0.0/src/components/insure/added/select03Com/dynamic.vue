<template>
  <section>
    <el-button @click="test">123</el-button>
    <div v-for="item in List">
      <!-- 表单 -->
      <Fold v-if="item.type === 'form'" :Name="item.name" @switch-form="item.show = !item.show" class="bt">
        <div v-if="item.show">
          <!-- 动态表单渲染 -->
          <el-form inline :model="submit" :rules="rules" ref="submit" label-width="175px" class="sync">
            <el-form-item v-for="(childItem, index) in item.children" :label="childItem.label + '：'" :key="index" :prop="childItem.model">

              <!-- 表单校验 -->
              <el-input v-if="childItem.type === 'input' && childItem.valid !== 'number'" v-model="submit[childItem.model]" :disabled="childItem.disable" placeholder="请输入"></el-input>
              <el-input v-else-if="childItem.type === 'input'" :maxlength="childItem.length || 0" v-model.number="submit[childItem.model]" :disabled="childItem.disable" placeholder="请输入"></el-input>
              <el-select v-else-if="childItem.type === 'select'" v-model="submit[childItem.model]" :disabled="childItem.disable" clearable filterable>
                <el-option v-for="sel in childItem.selectData" :value="sel.value" :label="sel.label" :key="sel.value"></el-option>
              </el-select>
              <!-- 表单校验 -->

              <span v-if="childItem.label === '免赔额'">元</span>
              <span v-if="childItem.label === '免赔率'">%</span>

              <span v-if="childItem.label === '是否已询价'">
                <span><i v-if="submit[childItem.model] === 1" class="red mr5">*</i>询价号</span>
                <el-input v-if="submit[childItem.model] === 1"></el-input>
                <el-input v-else-if="submit[childItem.model] === 2" disabled></el-input>
              </span>
            </el-form-item>
          </el-form>
          <!--动态表单渲染 -->
        </div>
      </Fold>

      <!-- 表格 -->
      <Fold v-if="item.type === 'table'" :Name="item.name" @switch-form="item.show = !item.show" class="bt">
        <div v-if="item.show">
          <!-- 动态表格渲染 -->
          <el-table :data="item.tableList" border>
            <el-table-column label="序号" width="45">
              <template slot-scope="ngScope">
                <span>{{ ngScope.$index + 1 }}</span>
              </template>
            </el-table-column>
            <el-table-column v-for="(column, index) in item.children" :key="column.value" :label="column.label" :width="column.width" min-width="180">
              <template slot-scope="ngScope">

                <!-- 解决下拉框value显示在表格中的问题 -->
                <div v-if="column.type === 'select'">
                  <span v-for="ts in column.selectData">
                    {{ ngScope.row[column.value] === ts.value ? ts.label : null }}
                  </span>
                </div>
                <span v-else>{{ ngScope.row[column.value] }}</span>
                <!-- 解决下拉框value显示在表格中的问题 -->
                
              </template>
            </el-table-column>
            <el-table-column label="操作" width="125">
              <template slot-scope="ngScope">
                <el-tooltip class="item" effect="dark" content="编辑" placement="top">
                  <i class="el-icon-edit editBtn" @click="edit(ngScope.row, ngScope.$index, item)"></i>
                </el-tooltip>
                <el-tooltip class="item" effect="dark" content="删除" placement="top">
                  <i class="el-icon-delete deleteBtn" @click="del(item.tableList, ngScope.$index, item)"></i>
                </el-tooltip>
              </template>
            </el-table-column>
          </el-table>
          <!--动态表格渲染 -->
          <div class="addBtn">
            <el-button v-if="!item.check" type="primary" size="mini" @click="addData(item)">新增</el-button>
            <el-button v-else type="primary" size="mini" @click="addPlan(item)">新增方案</el-button>
            <el-button v-if="item.additional" type="danger" size="mini" @click="clear(item)">删除附加险</el-button>
          </div>
        </div>
      </Fold>
    </div>

    <!-- 表格新增行弹出层 -->
    <el-dialog :title="dialogName" :visible.sync="openDialog" width="50%" :show-close="false" :close-on-press-escape="false" :close-on-click-modal="false">
      <el-form v-if="dialogCode === 1" :model="formSubmit" :rules="rules" ref="formSubmit" label-width="125px" class="sync">
        <el-form-item v-for="(childItem, index) in form" :label="childItem.label + '：'" :key="index" :prop="childItem.value">
          <!-- 表单校验 -->
          <el-input class="dialog" v-if="childItem.type === 'input' && childItem.valid !== 'number'" v-model="formSubmit[childItem.model]" :disabled="childItem.disable" placeholder="请输入"></el-input>
          <span v-else-if="childItem.type === 'input' && childItem.valid === 'number'">
            <span v-if="row.id !== 60172">
              <el-input v-if="childItem.model !== 'allowance' || childItem.model !== 'coverage'" class="dialog" type="number" :maxlength="childItem.length || 0" v-model.number="formSubmit[childItem.model]" :disabled="childItem.disable" placeholder="请输入"></el-input>
            </span>
            <span v-else-if="row.id === 60172">
              <el-input v-if="childItem.model === 'allowance'" class="dialog" type="number" :maxlength="childItem.length || 0" v-model.number="formSubmit[childItem.model]" :disabled="!childItem.disable" @change="allowance(formSubmit[childItem.model])" placeholder="请输入"></el-input>
              <el-input v-else-if="childItem.model === 'coverage'" class="dialog" type="number" :maxlength="childItem.length || 0" v-model.number="formSubmit[childItem.model]" :disabled="!childItem.disable" placeholder="请输入"></el-input>
              <el-input v-else class="dialog" type="number" :maxlength="childItem.length || 0" v-model.number="formSubmit[childItem.model]" :disabled="childItem.disable" placeholder="请输入"></el-input>
            </span>
          </span>
          <el-select class="dialog" v-else-if="childItem.type === 'select'" v-model="formSubmit[childItem.model]" :disabled="childItem.disable" clearable>
            <el-option v-for="sel in childItem.selectData" :value="sel.value" :label="sel.label" :key="sel.value"></el-option>
          </el-select>
          <!-- 表单校验 -->
        </el-form-item>
      </el-form>
      <el-table v-if="dialogCode === 2" :data="planTable" ref="planTableRef" class="mb20" @selection-change="selection" border>
        <el-table-column type="selection"></el-table-column>
        <el-table-column v-for="(item, index) in planTableLabel" :key="item.value" :label="item.label" :width="item.width" min-width="180">
          <template slot-scope="ngScope">
            {{ ngScope.row[item.value] }}
          </template>
        </el-table-column>
      </el-table>
      <div class="dialogBtn">
        <el-button type="primary" size="mini" @click="save('formSubmit')">保存</el-button>
        <el-button size="mini" @click="cancel('formSubmit')">取消</el-button>
      </div>
    </el-dialog>


  </section>
</template>

<script>
  import { mapGetters, mapMutations } from 'vuex'
  import { type } from './intable/utils'
  import Fold from 'utils/fold/fold'
  import { get_list, handleErr } from 'api'
  export default {
    name: 'dynamic',

    props: {},

    components: {
      Fold,
    },

    data() {
      return {
        max: '',
        show: true,
        openDialog: false,

        /* 险种ID */
        Id: 0,

        /* 提交数据 */
        tplSubmit: {},
        submit: {},
        selectData: {},

        /* 列表数据 */
        List: [],
        tableList: [],
        tplIndex: '',
        row: {},

        /* 新增弹窗 */
        dialogCode: 0,
        dialogName: '',
        form: {},
        addForm: {},
        addFlag: false,
        editForm: {},
        editFlag: false,
        tplFormSubmit: {},
        formSubmit: {},
        /* 方案编号 */
        P: 1,
        plancheck: [],
        planTable: [],
        planTableLabel: [],

        /* 表单校验 */
        rules: {},
      };
    },

    computed: {
      ...mapGetters([
        'getUnderWriting',
        'getPlanList',
        'getPlanSelect'
      ])
    },

    created() {
      this.initData()
    },

    mounted() {
    },

    methods: {
      async test() {
        console.log(this.submit, this.rules)
        let params = {
          currentPage: 1,
          pageSize: 1000,
        }
        try {
          let agin = await get_list(params)
          console.log(agin)
        } catch(err) {
          handleErr(err)
        }
      },

      /* 多选表格弹窗 */
      selection(val) {
        this.plancheck = val
      },

      /* 每日津贴金额处理 */
      allowance(num) {
        if(num % 10 !== 0) {
          alert('每日补贴金额必须为10的整倍数')
          this.formSubmit.allowance = ''
        }
      },

      /* 添加新数据 */
      addData(table) {
        this.dialogName = `新增${table.name}`
        this.addFlag = true
        /* 处理新增数据弹窗 */
        const TPL_DATA = this.flat(table.children, this.tplFormSubmit)
        this.form = table.children
        this.tableList = table.tableList
        this.formSubmit = { ...this.tplFormSubmit }
        this.dialogCode = 1
        this.openDialog = true
      },

      /* 新增方案 */
      addPlan(table) {
        this.dialogName = `新增${table.name}`
        this.dialogCode = 2
        if(this.Id === 100001) {
          this.planTable = [...this.getPlanList]
          this.planTableLabel = [...this.getPlanSelect]
        }
        this.openDialog = true
      },

      /* 编辑当前行 */
      edit(row, index, table) {
        this.dialogName = `编辑${table.name}`
        this.dialogCode = 1
        this.editFlag = true
        this.openDialog = true

        /* 处理编辑数据弹窗 */
        const TPL_DATA = this.flat(table.children, this.tplFormSubmit)
        this.form = table.children
        this.tableList = table.tableList
        this.row = row
        this.formSubmit = { ...table.tableList[index] }

        /* 临时 */
        this.tplIndex = index
        console.log(this.tableList, this.row)
      },

      /* 删除 */
      async del(row, index, tab) {
        let flag = 0
        let arr = []
        /* 删除当前行 */
        try {
          await this.$confirm('是否删除当前行内容？', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          })
          if(this.Id === 100001) {
            tab.tableList.forEach(item => {
              if(item.planCode === row[index].planCode) {
                arr.push(row[index])
              }
            })
            if(arr.length > 1 && row[index].id === 60171) {
              this.$message({
                type: 'warning',
                message: '当前方案下有依赖的附险，请先删除这些附险'
              })
            } else {
              await row.splice(index, 1)
              this.$message({
                message: '删除成功!',
                type: 'success'
              })
            }
          } else {
            await row.splice(index, 1)
            this.$message({
              message: '删除成功!',
              type: 'success'
            })
          }
        } catch(err) {
          console.log(tab)
          this.$message({
            message: '已取消操作',
            type: 'warning'
          })
        }
      },
      
      /* 保存/取消 */
      save(form) {
        if(this.dialogCode === 1) {
          this.$refs[form].validate(async (valid) => {
            if(valid) {
              try {
                // const TPL_DATA = { ...type(this.tableList, this.formSubmit, this.Id) }
                const tpl = { ...this.formSubmit }
                const TPL_DATA = { ...type(this.tableList, tpl, this.Id, this.row) }
                /* 表单校验通过后提交 */
                if (this.tplIndex !== '') {
                  this.$set(this.tableList, this.tplIndex, TPL_DATA)
                } else if (this.tplIndex === '') {
                  this.$set(this.tableList, this.tableList.length, TPL_DATA)
                }

                await this.submitData(this.List)
                await this.initData()

                this.openDialog = false
              } catch(err) {
                console.log(err)
              } finally {
                this.$refs[form].resetFields()
                this.formSubmit = {}
                this.tplIndex = ''
              }
            } else {
              return false
            }
          })
        } else if(this.dialogCode === 2) {
          try {
            if(this.Id === 100001) {
              let flag = 0
              /* 深拷贝obj/arr下所有子元素 */
              let tpl = JSON.parse(JSON.stringify(this.plancheck))
              
              tpl.forEach(item => {
                item.planCode += this.P
                if(item.id === 60171) {
                  flag += 1
                }
              })
              if(flag === 1) {
                this.List.forEach(item => {
                  item.name === '险别信息' ? item.tableList.push(...tpl) : ''
                })
                /* 方案号更新 */
                this.P += 1
                this.openDialog = false
              } else {
                this.$message({
                  type: 'warning',
                  message: '该方案下的主险060171未选择'
                })
              }
            }
          } catch(err) {
            console.log(err)
          }
        }
      },
      cancel(form) {
        this.openDialog = false
        this.dialogCode === 1 ? this.$refs[form].resetFields() : ''
        this.formSubmit = {}
        this.tplIndex = ''
      },

      /* 清除附加条款 */
      async clear(form) {
        try {
          await this.$confirm('是否清空当前所有附加条款？', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          })
          await form.tableList.splice(0, form.tableList.length)
          this.$message({
            message: '删除成功!',
            type: 'success'
          })
          await this.submitData(this.List)
          await this.initData()
        } catch(err) {
          this.$message({
            message: '已取消操作',
            type: 'warning'
          })
        }
      },

      /* 数据初始化 */
      initData() {
        /* 初始数据 */
        this.List = this.getUnderWriting.list
        this.Id = this.getUnderWriting.id

        /* 处理获取到的列表 */
        const FLAT_DATA = this.flat(this.List, this.tplSubmit)
        /* 解决Element下拉选择框不显示选择值的问题 */
        this.submit = Object.assign({}, this.tplSubmit)

        /* 将处理的数据通过mutation保存到Vuex */
        this.submitData(this.List)
      },

      /* 递归 */
      flat(arr, tplArr) {
        if(arr && arr instanceof Array) {
          arr.forEach(item => {
            /* 表单 */
            if(item) {
              if (item.children instanceof Array && item.children.length > 0) {
                this.flat(item.children, tplArr)
              } else {
                item.default ? tplArr[item.model] = item.default : item.model ? tplArr[item.model] = '' : null
                // item.model ? tplArr[item.model] = '' : null
                item.must && item.must === 1 ? this.rules[item.model] = [{ required: true, message: item.message, trigger: item.trigger }] : null
                item.valid && this.rules[item.model] ?
                  this.rules[item.model].forEach(newItem => {
                    newItem['type'] = item.valid
                  })
                  : null
              }
            }
          })
          return tplArr
        }
      },

      /* vuex */
      ...mapMutations({
        submitData: 'SET_UNDERWRITING_DATA'
      }),
    },

  };
</script>

<style lang="less" scoped>
  .bt {
    border-top: 1px solid #ddd;
  }
  .editBtn {
    color: #409EFF;
    margin: 0 10px;
    font-size: 17px;
    cursor: pointer;
  }
  .addBtn {
    
  }
  .deleteBtn {
    color: #409EFF;
    margin: 0 10px;
    font-size: 17px;
    cursor: pointer;
  }
  .dialogBtn {
    bottom: 15px !important;
    right: 15px !important;
    position: absolute;
    overflow: hidden;
  }
  .dialog {
    width: 60% !important;
  }
  .dialog .el-input--suffix .el-input__inner {
    width: 60% !important;
  }
  .red {
    color: red;
  }
</style>
