<template>
  <Fold Name="已上传附件" @switch-form="show = !show" class="bgFold bgSec">
    <section v-if="show" class="container">
      <el-table border :data="tableList">
        <el-table-column sortable label="影像类型"></el-table-column>
        <el-table-column sortable label="影像文件名"></el-table-column>
        <el-table-column sortable label="影像上传人"></el-table-column>
        <el-table-column sortable label="影像上传时间"></el-table-column>
        <el-table-column sortable label="影像描述"></el-table-column>
        <el-table-column sortable label="审查状态"></el-table-column>
      </el-table>
      <ul class="form right">
        <li class="empty">
          <el-button></el-button>
        </li>
        <li>
          <el-button type="primary" size="mini" icon="el-icon-caret-right" disabled>审核</el-button>
        </li>
        <li>
          <el-button type="primary" size="mini" icon="el-icon-caret-right">保存</el-button>
        </li>
        <li>
          <el-button type="primary" size="mini" icon="el-icon-caret-right">下载</el-button>
        </li>
        <li>
          <el-button type="primary" size="mini" icon="el-icon-caret-right">上传</el-button>
          <!-- <up-load></up-load> -->
        </li>
        <li>
          <el-button type="primary" size="mini" icon="el-icon-caret-right">查看</el-button>
        </li>
        <li>
          <el-button type="primary" size="mini" icon="el-icon-caret-right">删除</el-button>
        </li>
      </ul>
    </section>
  </Fold>
</template>

<script>
  import Fold from 'utils/fold/fold'
  import UpLoad from 'utils/upload/upload'
  export default {
    name: 'video',

    components: {
      Fold,
      UpLoad,
    },

    data() {
      return {
        show: true,
        tableList: [],
      }
    },

    computed: {
    },

    mounted() {
    },

    methods: {
    },
  }
</script>

<style lang="css" scoped>
  .bgFold >>> .Switch {
    border-top: 1px solid #ddd;
    /* background-color: #FFF; */
  }

  .bgSec >>> .container {
    background-color: #FFF;
  }
  
  .right {
    margin-top: 10px;
  }

  .right :nth-child(n+2) {
    float: right;
  }

  .empty {
    visibility: hidden;
  }
</style>
