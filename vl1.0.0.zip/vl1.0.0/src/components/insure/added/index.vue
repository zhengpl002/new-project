
<template>
  <div id="app">
    <!-- <section class="btn">
      <el-button size="mini" @click="save">保存</el-button>
    </section> -->
    <div class="radio-wrap">
      <div class="radio-group" v-model="tabView">
        <span v-for="(tab ,index) in tabs" :class="{cur:iscur==index}" @click="iscur=index,tabChange('select' + (index + 1))">{{tab.name}}</span>
      </div>
      <div style="margin:10px 0;" class="com_topform">
        <ul>
          <li>
            <el-button size="mini">续费</el-button>
          </li>
          <li>
            <el-button size="mini" @click="save">保存</el-button>
          </li>
          <li>
             <el-button size="mini">保费计算</el-button>
          </li>
          <li>
            <el-button size="mini">申请核保</el-button>
          </li>
        </ul>

      </div>
      <keep-alive>
        <component v-bind:is="tabView"></component>
      </keep-alive>
    </div>
  </div>
</template>
 
<script>
import select1 from './essentialInfor.vue';
import select2 from './select02.vue';
import select3 from './select03.vue';
import select4 from './select04.vue';
import { mapMutations, mapGetters, mapState } from 'vuex'
import { get_list, handleErr } from 'api'
export default {
  name: 'app',
  data() {
    return {
      tabView: 'select1',
      tabs: [{ name: "基本信息" }, { name: "客户信息" }, { name: "承保信息" }, { name: "影像信息" }],
      iscur: 0
    }
  },
  components: {
    select1,
    select2,
    select3,
    select4,
  },

  /* 页面缓存 */
  beforeRouteLeave(to, from, next) {
    if (to.name !== '客户视图') {
      from.meta.keepAlive = false
      /* 发生页面跳转时询问 */
      // this.routeLeave(next)
      const flag = confirm('离开当前页面将不会保存已填写数据，是否继续？')
      next(flag)
    } else {
      from.meta.keepAlive = true
      next()
    }
  },

  computed: {
    ...mapGetters([
      'getApplicant',
      'getInsured',
    ])
  },

  methods: {
    tabChange(tab) {
      this.tabView = tab;
    },

    /* 保存 */
    async save() {
      console.log(process.env)
      return
      let params = {
        currentPage: 1,
        pageSize: 1000,
      }
      try {
        let agin = await get_list(params)
      } catch (err) {
        handleErr(err)
      }
    },

    /* 页面跳转 */
    async routeLeave(next) {
      let flag = false
      try {
        await this.$confirm('离开当前页面将不会保存已填写数据，是否继续？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
          center: true,
        })
        flag = true
        next(flag)
      } catch (err) {
        this.$router.push({
          path: '/insure/added'
        })
        this.$message({
          type: 'warning',
          message: '已取消操作'
        })
        next(flag)
      }
    },

    ...mapMutations({
      saveData: 'SET_SAVE_DATA',
    })
  }
}
</script>
 
<style>
.radio-wrap {
  margin-top: 10px
}

.radio-group {
  font-size: 0;
  border-bottom: 2px solid #20a0ff;
}

.radio-group>span {
  cursor: pointer;
  display: inline-block;
  font-size: 16px;
  text-align: center;
  width: 100px;
}

.cur {
  color: #fff;
  border-left: #ddd solid 1px;
  border-top: #20a0ff solid 4px;
  border-right: #ddd solid 1px;
  color: #20a0ff;
  line-height: 32px;
}

.com_topform ul {
  list-style: none;
  background-color: #f5f5f5;
  border: 1px solid #e3e3e3;
  -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.05);
  -moz-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.05);
  box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.05);
  overflow: hidden;
  text-align: right;
  padding-right: 6px;
  padding-top: 6px;
  padding-bottom: 6px;
}
.com_topform ul li{
  margin-left: 8px;
    display: inline-table;
    line-height: 20px
}
</style>