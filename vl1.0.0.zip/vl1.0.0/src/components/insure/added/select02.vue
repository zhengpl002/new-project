<template>
  <section slot='select02' class="select02 container">
    <el-col :span="24">
      <!-- 投保人 -->
      <applicant ref="ref"></applicant>

      <!-- 被投保人 -->
      <insured></insured>

      <!-- 账户信息 -->
      <account-info></account-info>
    </el-col>
  </section>
</template>

<script>
  import Applicant from './select02Com/applicant'
  import Insured from './select02Com/insured'
  import AccountInfo from './select02Com/accountInfo'
  export default {
    components: {
      Applicant,
      Insured,
      AccountInfo,
    },
    data() {
      return {
        applicant: {},
        insured: {},
        accountInfo: {},
      }
    },
    watch: {
      
    },
    methods: {
    }
  }
</script>

<style scoped>
</style>

<!-- element默认样式修改 -->
<style>
  body {
    padding-right: 0 !important;
    overflow: none !important;
  }
  *.v-modal {
    overflow-y: scroll;
    padding-right: 27px !important;
  }
  .select02 {
    min-width: 1400px;
  }
</style>