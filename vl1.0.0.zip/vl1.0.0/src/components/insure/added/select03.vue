<template>
  <section slot='select03' class="select03 container">
    <insurance-period></insurance-period>
    <dynamic></dynamic>
    <essential-info></essential-info>
    <premium-split></premium-split>
    <payment-plan></payment-plan>
  </section>
</template>
 
<script>
  import InsurancePeriod from './select03Com/insurancePeriod'
  import Dynamic from './select03Com/dynamic'
  import EssentialInfo from './select03Com/essentialInfo'
  import PremiumSplit from './select03Com/premiumSplit'
  import PaymentPlan from './select03Com/paymentPlan'
  export default {
    data(){
      return{
      }
    },
    
    components: {
      InsurancePeriod,
      Dynamic,
      EssentialInfo,
      PremiumSplit,
      PaymentPlan,
    },

    mounted() {
    },
  }
</script>
 
<style lang="css" scoped>
  .select03 {
    min-width: 1400px;
  }
</style>