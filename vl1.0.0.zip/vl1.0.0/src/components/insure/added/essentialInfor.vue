<template>
  <div slot='select01' class="container">
    <!--基本信息  -->
    <div class="titleInfo">
      <span class="vertical"></span>基本信息</div>
    <ul class="form">
      <li>
        <span class="label">数据来源：</span>
        <el-input placeholder="" v-model="EssInfor.dataSources"></el-input>
      </li>
      <li>
        <span class="label">对外销售代码：</span>
        <el-input placeholder="请输入对外销售代码" v-model="EssInfor.salesCode"></el-input>
      </li>
      <li>
        <span class="label">投保单号：</span>
        <el-input placeholder="请输入投保单号" v-model="EssInfor.insureNumber"></el-input>
      </li>
      <li>
        <span class="label">保单标志：</span>
        <el-input placeholder="请输入保单号" v-model="EssInfor.insurancePolicy"></el-input>
      </li>
      <li>
        <span class="label">续保\复制单号：</span>
        <el-input placeholder="请输入续保\复制单号" v-model="EssInfor.renewalNumber"></el-input>
      </li>
      <li>
        <span class="label">保单号：</span>
        <el-input placeholder="请输入保单号" v-model="EssInfor.cDptAbr"></el-input>
      </li>
      <li>
        <span class="label">
          <i class="red">*</i>业务来源：</span>
        <el-input v-if="disable" v-model="EssInfor.businessSource" placeholder="请输入业务来源" :disabled="disable"></el-input>
        <div class="agencyCode" @click="showTree" v-if="!disable">
          {{EssInfor.businessSource}}
          <span class="font"></span>
        </div>
      </li>
      <li>
        <span class="label">
          <i class="red">*</i>机构部门：</span>
        <el-input placeholder="" v-model="EssInfor.insDepartment"></el-input>
      </li>
      <li>
        <span class="label">
          <i class="red">*</i>渠道中级分类：</span>
        <el-input placeholder="" v-model="EssInfor.intermediate"></el-input>
      </li>
      <li>
        <span class="label">
          <i class="red">*</i>渠道子类：</span>
        <el-input placeholder="" v-model="EssInfor.canals"></el-input>
      </li>
      <li>
        <span class="label">
          <i class="red">*</i>代理(经纪)人：</span>
        <el-input placeholder="" v-model="EssInfor.agent"></el-input>
      </li>
      <li>
        <span class="label">
          <i class="red">*</i>代理合作协议：</span>
        <el-input placeholder="" v-model="EssInfor.agencyAgreement"></el-input>
      </li>
      <li>
        <span class="label">
          <i class="red">*</i>补充协议号：</span>
        <el-input placeholder="" v-model="EssInfor.agreementNo"></el-input>
      </li>
      <li>
        <span class="label">
          <i class="red">*</i>代理业务员：</span>
        <el-input placeholder="" v-model="EssInfor.dsalesperson"></el-input>
      </li>
      <li>
        <span class="label">
          <i class="red">*</i>代理业务员名称：</span>
        <el-input placeholder="" v-model="EssInfor.dsalespersonName"></el-input>
      </li>
      <li>
        <span class="label">
          <i class="red">*</i>代理业务执业证号：</span>
        <el-input placeholder="" v-model="EssInfor.dsalespersonbNo"></el-input>
      </li>
      <li>
        <span class="label">
          <i class="red">*</i>业务执业证号：</span>
        <el-input placeholder="" v-model="EssInfor.salespersonbNo"></el-input>
      </li>
      <li>
        <span class="label">
          <i class="red">*</i>业务员工号：</span>
        <el-input placeholder="" v-model="EssInfor.salespersonNo"></el-input>
      </li>
      <li>
        <span class="label">
          业务员名称：</span>
        <el-input placeholder="" v-model="EssInfor.salespersonName"></el-input>
      </li>
      <li>
        <span class="label">
          业务员电话：</span>
        <el-input placeholder="" v-model="EssInfor.salespersonTel"></el-input>
      </li>
      <li>
        <span class="label">
          业务员所属团队：</span>
        <el-input placeholder="" v-model="EssInfor.salespersonTeam"></el-input>
      </li>
      <li>
        <span class="label">
          团队编码：</span>
        <el-input placeholder="" v-model="EssInfor.teamCoding"></el-input>
      </li>

      <li>
        <span class="label">
          单证号：</span>
        <el-input placeholder="" v-model="EssInfor.docNumber"></el-input>
      </li>
      <li>
        <span class="label">
          录单人：</span>
        <el-input placeholder="" v-model="EssInfor.recordSingle"></el-input>
      </li>
      <li>
        <span class="label">
          录单日期：</span>
        <el-input placeholder="" v-model="EssInfor. recordDate"></el-input>
      </li>
      <li>
        <span class="label">
          <i class="red">*</i>签单日期：</span>
        <el-date-picker v-model="EssInfor.timeStart" type="date" placeholder="签单日期" :editable="editable">
        </el-date-picker>
      </li>
      <li>
        <span class="label">
          共保方式：</span>
        <el-input placeholder="" v-model="EssInfor.cInbus"></el-input>
      </li>
      <li>
        <span class="label">
          是否涉水\涉海：</span>
        <el-select v-model="EssInfor.cWheade" placeholder="请选择">
          <el-option v-for="item in cWheade" :key="item.value" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
      </li>
      <li>
        <span class="label">涉农标志：</span>
        <el-select placeholder="请选择" v-model="EssInfor.cDrain">
          <el-option v-for="item in cDrain" :key="item.value" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
      </li>
    </ul>
    <ul class="form">
      <li>
        <span class="label">
          备注：</span>
        <el-input type="textarea" :rows="3" placeholder="请输入内容" v-model="EssInfor.textarea">
        </el-input>
      </li>
    </ul>
    <ul class="form">
      <li>
        <span class="label">
          <i class="red">*</i>可疑交易判断：</span>
        <el-select v-model="EssInfor.judgement" placeholder="请选择">
          <el-option v-for="item in judgement" :key="item.value" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
      </li>
    </ul>
    <ul class="form">
      <li class="descr">
        <span class="label descr">具体描述或合理解释：</span>
        <el-input placeholder="" v-model="EssInfor.description"></el-input>
        </el-select>
      </li>
    </ul>
    <div class="content"></div>
    <div class="tree" v-if='isShowTree' v-clickoutside="handleClose">
      <Tree :list.sync='ztree' :is-open='true' :product="product"></Tree>
    </div>
  </div>
</template>
 
<script>
import { formatTimestamp1 } from './../../../public/js/public';
export default {
  data() {
    return {
      isShowTree: false,
      editable: false,
      cWheade: [
        { label: '请选择', value: null },
        { label: '是', value: '1' },
        { label: '否', value: '2' },
      ],/*是否涉水*/
      cDrain: [
        { label: '请选择', value: null },
        { label: '涉农', value: '1' },
        { label: '非涉农', value: '2' },
      ],
      judgement: [
        { label: '未发现可疑交易', value: '1' },
        { label: '客户由不存在利益关系的他人代为投保', value: '2' },
        { label: '其他', value: '3' },
      ],

      EssInfor: {
        dataSources: '',/*数据来源*/
        salesCode: '',/*对外销售代码*/
        insureNumber: '',/*投保单号*/
        insurancePolicy: '',/*保单标志*/
        renewalNumber: '',/*续保\复制单号*/
        policyNumber: '',/*保单号*/
        businessSource: '',/*业务来源*/
        insDepartment: '',/*机构部门*/
        intermediate: '',/*渠道中级分类*/
        canals: '',/*渠道子类*/
        agent: '',/*代理(经纪)人*/
        agencyAgreement: '',/*代理合作协议*/
        agreementNo: '',/*补充协议号*/
        dsalesperson: '',/*代理业务员*/
        dsalespersonName: '',/*代理业务员名称*/
        dsalespersonbNo: '',/*代理业务执业证号*/
        salespersonbNo: '',/*业务执业证号*/
        salespersonNo: '',/*业务员工号*/
        salespersonName: '',/*业务员名称*/
        salespersonTel: '',/*业务员电话*/
        salespersonTeam: '',/*业务员所属团队*/
        teamCoding: '',/*团队编码*/
        docNumber: '',/*单证号*/
        recordSingle: '',/*录单人*/
        recordDate: formatTimestamp1(new Date()),/*录单日期*/
        timeStart: '',/*签单日期*/
        judgement: '1',
        description: '',/*具体描述*/

        cInbus: '',/*共保业务*/
        cDivbus: '2',/*分入业务*/
        cWheade: '2',/*是否涉水*/
        cRelist: '2',/*团单*/
        cDrain: '2',/*涉农标志*/
        textarea: '',/*备注*/
      },
      disable: false
      // msg: "select01"
    }
  },
  components: {
  },
  created() {
    // console.log(this.$store.getters.guide.query)
    // let query = this.$store.getters.guide.query;
    // this.EssInfor.cInbus = query.cInbus;
    // this.EssInfor.cDivbus = query.cDivbus;
    // this.EssInfor.cWheade = query.cWheade;
    // this.EssInfor.cRelist = query.cRelist;
    // this.EssInfor.cDrain = query.cDrain;

  },
  mounted() {
    this.$nextTick(function() {

    })
  },
  methods: {
    showTree() {

    }

  }
}
</script>
 
<style>
.container .form li.descr .label {
  width: 120px;
}

.container .form li.descr .el-input,
.el-textarea {
  width: 500px;
}
</style>
