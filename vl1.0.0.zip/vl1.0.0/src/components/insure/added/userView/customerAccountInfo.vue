<template>
  <Fold class="test" Name="客户账户信息" @switch-form="show = !show">
    <section v-if="show" class="formPersonal">
      <ul class="form right">
        <li>
          <span class="label">账号名称：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
        <li>
          <span class="label"><i class="red">*</i>账号：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
        <li>
          <span class="label">银行省份：</span>
          <el-select v-model="test" disabled>
            <el-option v-for="item in testArr" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
      </ul>
      
      <ul class="form right">
        <li>
          <span class="label">银行城市：</span>
          <el-select v-model="test" disabled>
            <el-option v-for="item in testArr" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label"><i class="red">*</i>银行代码：</span>
          <el-select v-model="test" disabled>
            <el-option v-for="item in testArr" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label"><i class="red">*</i>开户行：</span>
          <el-select v-model="test" disabled>
            <el-option v-for="item in testArr" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
      </ul>
      
      <ul class="form right">
        <li>
          <span class="label"><i class="red">*</i>开户行地址：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
        <li>
          <span class="label"><i class="red">*</i>币种：</span>
          <el-select v-model="test" disabled>
            <el-option v-for="item in testArr" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label"><i class="red">*</i>收款人：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
      </ul>
      
      <ul class="form right">
        <li>
          <span class="label">失效时间：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
        <li>
          <span class="label">是否有效：</span>
          <el-select v-model="test" disabled>
            <el-option v-for="item in testArr" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
      </ul>
    </section>
  </Fold>
</template>

<script>
  import Fold from 'utils/fold/fold'
  export default {
    name: "CustomerAccountInfo",

    components: {
      Fold,
    },
  
    data() {
      return {
        show: true,
        test: '',
        testArr: [
          { name: '数据1', value: 1, key: 1, },
          { name: '数据2', value: 2, key: 2, },
          { name: '数据3', value: 3, key: 3, },
        ],
      }
    },
  }
</script>

<style lang="less" scoped>
  .formPersonal {
    height: 100%;
  }
  .container .form li .label {
    width: 210px;
  }
</style>

<style>
  .test .Switch {
    width: 120px;
  }
</style>