<template>
  <Fold Name="个人客户" @switch-form="show = !show">
    <section v-if="show" class="formPersonal">
      <ul class="form right">
        <li>
          <span class="label"><i class="red">*</i>客户名称：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
        <li>
          <span class="label">客户简称：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
        <li>
          <span class="label">英文名称：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
      </ul>
      
      <ul class="form right">
        <li>
          <span class="label">英文简称：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
        <li>
          <span class="label"><i class="red">*</i>性别：</span>
          <el-select v-model="test" disabled>
            <el-option v-for="item in testArr" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label"><i class="red">*</i>职业：</span>
          <el-select v-model="test" disabled>
            <el-option v-for="item in testArr" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
      </ul>

      <ul class="form right">
        <li>
          <span class="label"><i class="red">*</i>身份证号：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
        <li>
          <span class="label"><i class="red">*</i>有效期：</span>
          <el-select v-model="test" disabled>
            <el-option v-for="item in testArr" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label"><i class="red">*</i>其他身份证明文件类别：</span>
          <el-select v-model="test" disabled>
            <el-option v-for="item in testArr" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
      </ul>
      
      <ul class="form right">
        <li>
          <span class="label"><i class="red">*</i>联系电话：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
        <li>
          <span class="label"><i class="red">*</i>手机号码：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
        <li>
          <span class="label"><i class="red">*</i>其他身份证明文件证件号码：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
      </ul>
      
      <ul class="form right">
        <li>
          <span class="label"><i class="red">*</i>工作单位：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
        <li>
          <span class="label"><i class="red">*</i>联系人：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
        <li>
          <span class="label"><i class="red">*</i>其他身份证明文件有效期：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
      </ul>
      
      <ul class="form right">
        <li>
          <span class="label">客户类别：</span>
          <el-select v-model="test" disabled>
            <el-option v-for="item in testArr" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label"><i class="red">*</i>单位地址：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
        <li>
          <span class="label"><i class="red">*</i>投保人与被保险人是何关系：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
      </ul>
      
      <ul class="form right">
        <li>
          <span class="label"><i class="red">*</i>客户级别：</span>
          <el-select v-model="test" disabled>
            <el-option v-for="item in testArr" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label"><i class="red">*</i>单位性质：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
        <li>
          <span class="label"><i class="red">*</i>投保人与指定受益人是何关系：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
      </ul>
      
      <ul class="form right">
        <li>
          <span class="label"><i class="red">*</i>经办机构：</span>
          <el-input v-model="test" disabled></el-input>
          <el-button size="mini" disabled>选择...</el-button>
        </li>
        <li>
          <span class="label">授权标志：</span>
          <el-select v-model="test" disabled>
            <el-option v-for="item in testArr" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label"><i class="red">*</i>是否有效：</span>
          <el-select v-model="test" disabled>
            <el-option v-for="item in testArr" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
      </ul>
            
      <ul class="form right">
        <li>
          <span class="label">经办人：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
        <li>
          <span class="label">客户来源：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
      </ul>

      <ul class="form country">
        <li>
          <span class="label"><i class="red">*</i>国家：</span>
          <el-select v-model="test" class="address" disabled>
            <el-option v-for="item in testArr" :value="item.name" :label="item.name" :key="item.value"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label"><i class="red">*</i>省</span>
          <el-select v-model="test" class="address" disabled>
            <el-option v-for="item in testArr" :value="item.name" :label="item.name" :key="item.value"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label"><i class="red">*</i>地市</span>
          <el-select v-model="test" class="address" disabled>
            <el-option v-for="item in testArr" :value="item.name" :label="item.name" :key="item.value"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label">县</span>
          <el-select v-model="test" class="address" disabled>
            <el-option v-for="item in testArr" :value="item.name" :label="item.name" :key="item.value"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label">街</span>
          <el-input v-model="test" disabled></el-input>
        </li>
      </ul>
      
      <ul class="form showAddress">
        <li>
          <span class="label"><i class="red">*</i>住所地或经常居住地：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
      </ul>
      
      <ul class="form right">
        <li>
          <span class="label"><i class="red">*</i>邮编：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
        <li>
          <span class="label">传真：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
        <li>
          <span class="label">是否股东客户：</span>
          <el-select v-model="test" disabled>
            <el-option v-for="item in testArr" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
      </ul>
      
      <ul class="form right">
        <li>
          <span class="label">是否员工：</span>
          <el-select v-model="test" disabled>
            <el-option v-for="item in testArr" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label">员工关联代码：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
        <li>
          <span class="label">是否合作伙伴：</span>
          <el-select v-model="test" disabled>
            <el-option v-for="item in testArr" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
      </ul>
      
      <ul class="form right">
        <li>
          <span class="label">合作伙伴代码：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
        <li>
          <span class="label">出生日期：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
        <li>
          <span class="label">籍贯/出生地：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
      </ul>
      
      <ul class="form right">
        <li>
          <span class="label">个人电子邮箱：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
        <li>
          <span class="label">职称：</span>
          <el-select v-model="test" disabled>
            <el-option v-for="item in testArr" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label">职务：</span>
          <el-select v-model="test" disabled>
            <el-option v-for="item in testArr" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
      </ul>
      
      <ul class="form right">
        <li>
          <span class="label">房产状况：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
        <li>
          <span class="label">年收入：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
        <li>
          <span class="label">民族：</span>
          <el-select v-model="test" disabled>
            <el-option v-for="item in testArr" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
      </ul>
      
      <ul class="form right">
        <li>
          <span class="label">婚姻状况：</span>
          <el-select v-model="test" disabled>
            <el-option v-for="item in testArr" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label">学历：</span>
          <el-select v-model="test" disabled>
            <el-option v-for="item in testArr" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label">毕业院校：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
      </ul>
      
      <ul class="form right">
        <li>
          <span class="label">车型：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
        <li>
          <span class="label">车牌号：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
        <li>
          <span class="label">专业：</span>
          <el-select v-model="test" disabled>
            <el-option v-for="item in testArr" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
      </ul>
      
      <ul class="form right">
        <li>
          <span class="label">个人偏好：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
        <li>
          <span class="label"><i class="red">*</i>分公司归并标志：</span>
          <el-select v-model="test" disabled>
            <el-option v-for="item in testArr" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label">分公司归并编码：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
      </ul>
      
      <ul class="form right">
        <li>
          <span class="label"><i class="red">*</i>总公司归并标志：</span>
          <el-select v-model="test" disabled>
            <el-option v-for="item in testArr" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label">总公司归并编码：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
        <li>
          <span class="label">单位邮编：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
      </ul>
      
      <ul class="form right">
        <li>
          <span class="label">上级部门代码：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
        <li>
          <span class="label">单位电子邮箱：</span>
          <el-input v-model="test" disabled></el-input>
        </li>
      </ul>

      <ul class="form textarea">
        <li>
          <span class="label">备注：</span>
          <el-input v-model="test" type="textarea" :rows="3" disabled></el-input>
        </li>
      </ul>
    </section>
  </Fold>
</template>

<script>
  import Fold from 'utils/fold/fold'
  export default {
    name: "personalCustomer",

    components: {
      Fold,
    },

    data() {
      return {
        show: true,
        test: '',
        testArr: [
          { name: '数据1', value: 1, key: 1, },
          { name: '数据2', value: 2, key: 2, },
          { name: '数据3', value: 3, key: 3, },
        ],
      }
    },
  }
</script>

<style lang="less" scoped>
  .formPersonal {
    height: 100%;
  }
  .container .form li .label {
    width: 210px;
  }
  .el-button--mini {
    height: 27px;
    top: 239px;
    left: 465px;
    position: absolute;
  }
  .container .country :nth-child(n+2) {
    margin-left: 0;
  }
  .container .country :nth-child(2) .label {
    width: 25px;
  }
  .container .country :nth-child(3) .label {
    width: 38px;
  }
  .container .country :nth-child(4) .label {
    width: 13px;
  }
  .container .country :nth-child(5) .label {
    width: 13px;
  }
  .container .country :nth-child(5) .el-input {
    width: 320px;
  }
</style>

<style>
  .container .country li .el-input {
    width: 120px;
  }
  .container .showAddress :first-child .el-input {
    width: 800px;
  }
  .textarea .el-textarea.is-disabled .el-textarea__inner {
    width: 800px;
  }
</style>