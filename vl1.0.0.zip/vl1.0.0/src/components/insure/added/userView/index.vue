<template>
  <div id="user">
    <div class="radio-wrap">
      <div class="radio-group" v-model="tabView"> 
        <span v-for="(item, index) in tabs" :class="{cur:iscur==index}" @click="iscur=index,tabChange(item)">{{item.name}}</span>
      </div>
      <div style="margin:10px 0;"></div>
      <keep-alive> 
        <component :is="tabView"></component>
      </keep-alive> 
    </div>
  </div>
</template>

<script>
import UserInfo from './userInfo'
export default {
  name: "user",

  components: {
    UserInfo,
  },

  data() {
    return {
      tabView: 'UserInfo',
      tabs: [
        { name: '客户信息', tab: 'UserInfo' },
        { name: '赔案信息', tab: '' }
      ],
      iscur: 0,
    }
  },

  beforeRouteEnter (to, from, next) {
    // 判断页面是否刷新,如果刷新则返回主页
    if(from.name) {
      next()
    } else {
      next(vm => {
        /* 访问组件实例 */
        vm.$router.push({
          path: '/insure/added'
        })
      })
    }
  },

  beforeRouteLeave (to, from, next) {
    if(to.name === '新增投保') {
      to.meta.keepAlive = true
    }
    next()
  },

  methods: {
    tabChange(val) {
      this.tabView = val.tab
    },
  },
}
</script>

<style scoped>
  .radio-wrap{margin-top: 10px;}
  .radio-group{font-size:0;height: 26px;line-height:26px;}
  .radio-group>span{cursor:pointer;display:inline-block;font-size:16px;text-align:center;width:100px;}
  .cur{color:#fff;background-color: #20a0ff;}
</style>