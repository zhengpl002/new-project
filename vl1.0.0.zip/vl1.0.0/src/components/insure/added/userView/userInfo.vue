<template>
  <section slot='userInfo' class="userInfo container">
    <el-col :span="24">
      <!-- 个人客户 -->
      <personal-customer></personal-customer>

      <!-- 客户账户信息 -->
      <customer-account-info></customer-account-info>
    </el-col>
  </section>
</template>

<script>
  import PersonalCustomer from './personalCustomer'
  import CustomerAccountInfo from './customerAccountInfo'
  export default {
    name: "UserInfo",

    components: {
      PersonalCustomer,
      CustomerAccountInfo,
    },

    data() {
      return {
      }
    },
  }
</script>

<style scoped>
  .userInfo {
    min-width: 1500px;
  }
</style>