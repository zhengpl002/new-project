
<template>
   <div id="tree">
             <el-tree v-loading="loading" style="width: 400px;"
              ref="tree"
              :props="defaultProps"
              :load="loadNode"
              :data="items"
              node-key="id"
              :expand-on-click-node="false"
              lazy
              :check-strictly="true"
              @check-change="checkChange"
              show-checkbox>
            </el-tree>
        </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
