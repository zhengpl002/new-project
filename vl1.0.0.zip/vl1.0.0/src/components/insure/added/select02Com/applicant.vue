<template>
  <Fold Name="投保人" @switch-form="showApplicant = !showApplicant">
    <div class="nature">
      <el-radio-group v-model="nature" size="mini">
        <el-radio-button label="自然人"></el-radio-button>
        <el-radio-button label="非自然人"></el-radio-button>
      </el-radio-group>
    </div>
    <!-- 表单部分 -->
    <section v-if="showApplicant && nature === '自然人'" class="formApplicant">
      <!-- 投保人表单部分 -->
      <!-- <el-form inline label-width="125px" class="right">
        <el-form-item label="客户代码：">
          <el-input v-model="applicantData.userCode" disabled></el-input>
        </el-form-item>
        <el-form-item label="投保人性质：">
          <el-select clearable v-model="applicantData.naturePolicyholder">
            <el-option v-for="item in getSelectData.naturePolicy" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="客户名称：">
          <el-input v-model="applicantData.userName" placeholder=""></el-input>
        </el-form-item>
      </el-form> -->
      <ul class="form right">
        <li>
          <span class="label"><i class="red">*</i>客户代码：</span>
          <el-input v-model="applicantData.userCode" disabled></el-input>
        </li>
        <li>
          <span class="label"><i class="red">*</i>投保人性质：</span>
          <el-select clearable v-model="applicantData.naturePolicyholder">
            <el-option v-for="item in getSelectData.naturePolicy" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label"><i class="red">*</i>客户名称：</span>
          <el-input v-model="applicantData.userName" placeholder=""></el-input>
        </li>
      </ul>

      <ul class="form right">
        <li>
          <span class="label"><i class="red">*</i>证件类型：</span>
          <el-select clearable v-model="applicantData.certificatesType">
            <el-option v-for="item in getSelectData.certificates" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label">有效期至：</span>
          <el-date-picker v-model="applicantData.effective" type="date" placeholder="选择日期"></el-date-picker>
        </li>
        <li>
          <span class="label"><i class="red">*</i>证件号码：</span>
          <el-input v-model="applicantData.certificatesCode" placeholder=""></el-input>
        </li>
      </ul>

      <ul class="form right">
        <li>
          <span class="label">职业：</span>
          <el-input v-model="applicantData.occupation" placeholder=""></el-input>
        </li>
        <li>
          <span class="label">股东客户：</span>
          <el-select clearable v-model="applicantData.shareholderUser" placeholder="请选择">
            <el-option v-for="item in getSelectData.shareholder" :value="item.value" :label="item.name" :key="item.value"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label">性别：</span>
          <el-select clearable v-model="applicantData.sex" placeholder="">
            <el-option v-for="item in getSelectData.selectSex" :value="item.value" :label="item.name" :key="item.value"></el-option>
          </el-select>
        </li>
      </ul>

      <ul class="form country">
        <li>
          <span class="label">通讯地址：</span>
          <el-select @change="address" clearable v-model="applicantData.country" placeholder="请选择" class="address">
            <el-option v-for="item in getCountry" :value="item.name" :label="item.name" :key="item.code"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label">国家</span>
        </li>
        <li>
          <el-cascader :options="city" :props="props" v-model="selectCountry" placeholder="搜索：北京" filterable clearable change-on-select @change="region">
          </el-cascader>
        </li>
        <li>
          <span class="label">街</span>
          <el-input @change="street" v-model="applicantData.street" placeholder="请选择"></el-input>
        </li>
      </ul>

      <!-- <el-form inline label="125px" class="right">
          <el-form-item label="通讯地址：">
            <el-input v-model="applicantData.address" disabled></el-input>
          </el-form-item>
        </el-form> -->
      <ul class="form right showAddress">
        <li>
          <span class="label">通讯地址：</span>
          <el-input v-model="applicantData.address" disabled></el-input>
        </li>
        <li>
          <span class="label"><i class="red">*</i>邮编：</span>
          <el-input @change="zipCode" :maxlength=6 v-model="applicantData.zipCode"></el-input>
        </li>
      </ul>

      <ul class="form right">
        <li>
          <span class="label"><i class="red">*</i>反洗钱客户风险等级：</span>
          <el-select clearable v-model="applicantData.reason" placeholder="请选择" class="address">
            <el-option v-for="item in getSelectData.reasonArr" :value="item.value" :label="item.name" :key="item.value"></el-option>
          </el-select>
          <i class="red ml5">*</i>
          <el-select clearable v-model="applicantData.level" placeholder="请选择" class="address">
            <el-option v-for="item in getSelectData.levelArr" :value="item.value" :label="item.name" :key="item.value"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label"><i class="red">*</i>固定电话：</span>
          <el-input v-model="applicantData.fixedTelephone"></el-input>
        </li>
        <li>
          <span class="label">经办联系人：</span>
          <el-input v-model="applicantData.managingContacts"></el-input>
        </li>
      </ul>

      <ul class="form right">
        <li>
          <span class="label"><i class="red">*</i>移动电话：</span>
          <el-input v-model="applicantData.moveTelephone"></el-input>
        </li>
        <li>
          <span class="label">Email：</span>
          <el-input v-model="applicantData.Email"></el-input>
        </li>
        <li>
          <span class="label">传真：</span>
          <el-input v-model="applicantData.fax"></el-input>
        </li>
      </ul>

      <ul class="form right">
        <li>
          <span class="label"><i class="red">*</i>纳税人资质：</span>
          <el-select clearable v-model="applicantData.taxpayerAptitude" placeholder="请选择" class="address">
            <el-option v-for="item in getSelectData.taxpayerAptitudeArr" :value="item.value" :label="item.name" :key="item.value"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label">银行帐号：</span>
          <el-input v-model="applicantData.bankAccount"></el-input>
        </li>
        <li>
          <span class="label">开户行：</span>
          <el-input v-model="applicantData.openingBank"></el-input>
        </li>
      </ul>

      <ul class="form right">
        <li>
          <span class="label"><i class="red">*</i>发票类型：</span>
          <el-select clearable v-model="applicantData.invoiceType" placeholder="请选择" class="address">
            <el-option v-for="item in getSelectData.invoiceTypeArr" :value="item.value" :label="item.name" :key="item.value"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label">纳税人识别号：</span>
          <el-input v-model="applicantData.taxpayerCode"></el-input>
        </li>
        <li>
          <span class="label"><i class="red">*</i>发票介质：</span>
          <el-select clearable v-model="applicantData.invoiceMedium" placeholder="请选择" class="address">
            <el-option v-for="item in getSelectData.invoiceMediumArr" :value="item.value" :label="item.name" :key="item.value"></el-option>
          </el-select>
        </li>
      </ul>

      <ul class="form right">
        <li>
          <span class="label"><i class="red">*</i>开票电话：</span>
          <el-input v-model="applicantData.drawBillTel"></el-input>
        </li>
        <li class="empty">
          <span class="label">空占位符：</span>
          <el-input></el-input>
        </li>
        <li>
          <span class="label"><i class="red">*</i>开票地址：</span>
          <el-input v-model="applicantData.drawBillAddress"></el-input>
        </li>
      </ul>
      <ul class="form right">
        <li class="empty">
          <el-button></el-button>
        </li>
        <li>
          <el-button type="primary" size="mini" icon="el-icon-caret-right" @click="result">客户重置</el-button>
        </li>
        <li>
          <el-button type="primary" size="mini" icon="el-icon-caret-right" @click="confirm">客户确认</el-button>
        </li>
        <li>
          <el-button type="primary" size="mini" icon="el-icon-caret-right" @click="open = true">查询客户</el-button>
        </li>
      </ul>
    </section>
    <section v-if="showApplicant && nature === '非自然人'" class="formApplicant">
      <div style="text-align: center;margin: 30px;">非自然人表单</div>
    </section>

    <Sel v-if="modal" :visible.sync="open" @close="close"></Sel>
  </Fold>
</template>

<script>
  import { mapGetters, mapMutations, } from 'vuex'
  import Fold from 'utils/fold/fold'
  import Sel from 'utils/selectUser/sel'
  export default {
    name: "",

    components: {
      Fold,
      Sel,
    },

    data() {
      return {
        showApplicant: true,
        modal: true,
        open: false,

        nature: '自然人',

        /* 地址拼接展示数据 */
        countrySplic: '',
        // provinceSplic: '',
        citySplic: '',
        // areaSplic: '',
        streetSplic: '',

        applicantData: {},

        country: [],
        city: [],
        selectCountry: [],
        props: {
          value: 'name',
          label: 'name',
          children: 'children',
        }
      }
    },

    watch: {
      '$route'(to, from) {
        if (to.name === '客户视图') {
          this.modal = false
        } else if (from.name === '客户视图') {
          this.modal = true
        }
      },

      nature(newVal) {
        newVal === '非自然人' ? this.applicantData.naturePolicyholder = 1 : ''
        newVal === '自然人' ? this.applicantData.naturePolicyholder = 2 : ''
      }
    },

    computed: {
      ...mapGetters([
        'getApplicant',
        'getSelectData',
        'getCountry',
        'getCity',
      ]),

    },

    methods: {
      /* 客户确认 */
      confirm() {
        this.formData(this.applicantData)
      },

      /* 客户重置 */
      async result() {
        try {
          await this.$confirm('是否清除原有数据，重新添加新客户？', '重置', {
            confirmButtonText: '重置',
            cancelButtonText: '取消',
            type: 'warning'
          })

          this.applicantData.userCode = ''
          this.applicantData.userName = ''
          this.applicantData.naturePolicyholder = ''
          this.applicantData.certificatesType = ''
          this.applicantData.certificatesCode = ''
          this.applicantData.effective = ''
          this.applicantData.occupation = ''
          this.applicantData.sex = ''
          this.applicantData.shareholderUser = 1
          this.applicantData.country = ''
          // this.applicantData.province = ''
          // this.applicantData.city = ''
          // this.applicantData.area = ''
          this.applicantData.street = ''
          this.applicantData.address = ''
          this.applicantData.zipCode = ''
          this.applicantData.level = ''
          this.applicantData.reason = ''
          this.applicantData.managingContacts = ''
          this.applicantData.fixedTelephone = ''
          this.applicantData.moveTelephone = ''
          this.applicantData.fax = ''
          this.applicantData.Email = ''
          this.applicantData.taxpayerAptitude = ''
          this.applicantData.bankAccount = ''
          this.applicantData.openingBank = ''
          this.applicantData.invoiceType = ''
          this.applicantData.taxpayerCode = ''
          this.applicantData.invoiceMedium = ''
          this.applicantData.drawBillTel = ''
          this.applicantData.drawBillAddress = ''
          this.selectCountry = []

          // 清空数据后传递给Mutations
          this.formData(this.applicantData)
        } catch (err) {
          this.$message({
            type: 'warning',
            message: '已取消重置',
          })
        }
      },

      /* 验证证件号码是否为number */
      zipCode(num) {
        /* 判断输入是否为数字 */
        const flag = /^[0-9]*$/u.test(num)
        if (!flag && num !== undefined) {
          alert('邮编只能输入数字', num)
          this.applicantData.zipCode = ''
        }
      },

      /* 处理地址格式 */
      address(val) {
        val === '中国' ? this.city = this.getCity : this.city = []
        if(val === '日本' || val === '美国' || val === '韩国') {
          this.$alert('该客户需要关注', '注意', {
            confirmButtonText: '确定'
          })
        }
        this.countrySplic = val
        this.citySplic = ''
        this.selectCountry = []
        let reg = this.selectCountry.join('')
        this.applicantData.address = `${this.countrySplic}${reg}${this.streetSplic}`
      },

      region(val) {
        this.citySplic = val.join('')
        this.applicantData.address = `${this.countrySplic}${this.citySplic}${this.streetSplic}`
      },

      street(val) {
        let reg = this.selectCountry.join('')
        this.streetSplic = val
        this.applicantData.address = `${this.countrySplic}${reg}${this.streetSplic}`
      },
      /* 处理地址格式 */

      close() {
        this.open = false
      },

      ...mapMutations({
        formData: 'SET_APPLICANT_DATA',
      }),
    },

    created() {
      let { ...tplData } = this.getApplicant
      this.applicantData = tplData
      this.city = this.getCity
      this.countrySplic = '中国'
      this.applicantData.country = '中国'

      this.nature === '自然人' ? this.applicantData.naturePolicyholder = 2 : ''
    },
  }
</script>

<style lang="css" scoped>
  .sec>.formApplicant {
    height: 100%;
  }

  .nature {
    width: 300px;
    height: 40px;
    line-height: 40px;
    position: absolute;
    margin: 0 auto;
    top: 0;
    right: 0;
  }
  .nature > .el-radio-group {
    margin-left: 140px;
  }
  .empty {
    visibility: hidden;
  }

  .btn {
    float: right;
  }

  .ml5 {
    left: 0;
    margin-top: 4px;
    margin-left: 8px;
  }

  .right :nth-child(n+2) {
    float: right;
  }
</style>