<template>
  <Fold Name="被保人" @switch-form="showInsured = !showInsured">
    <section v-if="showInsured" class="formInsured">
      <!-- 投保人表单部分 -->
      <ul class="form right">
        <li>
          <span class="label"><i class="red">*</i>客户代码：</span>
          <el-input v-model="insuredData.userCode" disabled></el-input>
        </li>
        <li>
          <span class="label"><i class="red">*</i>被保人性质：</span>
          <el-select clearable v-model="insuredData.naturePolicyholder">
            <el-option v-for="item in getSelectData.naturePolicy" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label"><i class="red">*</i>客户名称：</span>
          <el-input v-model="insuredData.userName" placeholder=""></el-input>
        </li>
      </ul>

      <ul class="form right">
        <li>
          <span class="label"><i class="red">*</i>证件类型：</span>
          <el-select clearable v-model="insuredData.certificatesType">
            <el-option v-for="item in getSelectData.certificates" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label">有效期至：</span>
          <el-date-picker v-model="insuredData.effective" type="date" placeholder="选择日期"></el-date-picker>
        </li>
        <li>
          <span class="label"><i class="red">*</i>证件号码：</span>
          <el-input v-model="insuredData.certificatesCode" placeholder=""></el-input>
        </li>
      </ul>

      <ul class="form right">
        <li>
          <span class="label">职业：</span>
          <el-input v-model="insuredData.occupation" placeholder=""></el-input>
        </li>
        <li>
          <span class="label">股东客户：</span>
          <el-select clearable v-model="insuredData.shareholderUser" placeholder="请选择">
            <el-option v-for="item in getSelectData.shareholder" :value="item.value" :label="item.name" :key="item.value"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label">性别：</span>
          <el-select clearable v-model="insuredData.sex" placeholder="">
            <el-option v-for="item in getSelectData.selectSex" :value="item.value" :label="item.name" :key="item.value"></el-option>
          </el-select>
        </li>
      </ul>

      <ul class="form country">
        <li>
          <span class="label">通讯地址：</span>
          <el-select @change="address" clearable v-model="insuredData.country" placeholder="请选择" class="address">
            <el-option v-for="item in getCountry" :value="item.name" :label="item.name" :key="item.value"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label">国家</span>
        </li>
        <li>
          <el-cascader :options="city" :props="props" v-model="selectCountry" placeholder="搜索：北京" filterable change-on-select @change="region">
          </el-cascader>
        </li>
        <li>
          <span class="label">街</span>
          <el-input @change="street" v-model="insuredData.street" placeholder="请选择"></el-input>
        </li>
      </ul>

      <ul class="form right showAddress">
        <li>
          <span class="label">通讯地址：</span>
          <el-input v-model="insuredData.address" disabled></el-input>
        </li>
        <li>
          <span class="label"><i class="red">*</i>邮编：</span>
          <el-input @change="zipCode" :maxlength=6 v-model="insuredData.zipCode"></el-input>
        </li>
      </ul>

      <ul class="form right">
        <li>
          <span class="label"><i class="red">*</i>反洗钱客户风险等级：</span>
          <el-select clearable v-model="insuredData.level" placeholder="请选择" class="address">
            <el-option v-for="item in getSelectData.reasonArr" :value="item.value" :label="item.name" :key="item.value"></el-option>
          </el-select>
          <i class="red ml5">*</i>
          <el-select clearable v-model="insuredData.reason" placeholder="请选择" class="address">
            <el-option v-for="item in getSelectData.levelArr" :value="item.value" :label="item.name" :key="item.value"></el-option>
          </el-select>
        </li>
        <li>
          <span class="label">经办联系人：</span>
          <el-input v-model="insuredData.managingContacts"></el-input>
        </li>
        <li>
          <span class="label"><i class="red">*</i>单位性质：</span>
          <el-select v-model="insuredData.unitProperties">
            <el-option v-for="item in getSelectData.reasonArr" :value="item.value" :label="item.name" :key="item.value"></el-option>
          </el-select>
        </li>
      </ul>

      <ul class="form right">
        <li>
          <span class="label">经办人身份证号码：</span>
          <el-input v-model="insuredData.agentCard"></el-input>
        </li>
        <li>
          <span class="label">固定电话：</span>
          <el-input v-model="insuredData.fixedTelephone"></el-input>
        </li>
        <li>
          <span class="label">经办人证件有效期至：</span>
          <el-date-picker v-model="insuredData.agentCardDate" type="date" placeholder="选择日期"></el-date-picker>
        </li>
      </ul>

      <ul class="form right">
        <li>
          <span class="label">移动电话：</span>
          <el-input v-model="insuredData.level" placeholder="请选择" class="address"></el-input>
        </li>
        <li>
          <span class="label">法定代表人姓名：</span>
          <el-input v-model="insuredData.legalRepresentative"></el-input>
        </li>
        <li>
          <span class="label">传真：</span>
          <el-input v-model="insuredData.fax"></el-input>
        </li>
      </ul>

      <ul class="form right">
        <li>
          <span class="label">法定代表人身份证号：</span>
          <el-input v-model="insuredData.legalRepresentativeCode" placeholder="请选择" class="address"></el-input>
        </li>
        <li>
          <span class="label">组织机构代码：</span>
          <el-input v-model="insuredData.organizationCodeCertificate"></el-input>
        </li>
        <li>
          <span class="label long">法定代表人证件有效期至：</span>
          <el-date-picker v-model="insuredData.legalRepresentativeDate" type="date" placeholder="选择日期"></el-date-picker>
        </li>
      </ul>

      <ul class="form right">
        <li>
          <span class="label">税务登记证号：</span>
          <el-input v-model="insuredData.taxRegistrationCertificate"></el-input>
        </li>
        <li class="empty">
          <span class="label">空占位符：</span>
          <el-input></el-input>
        </li>
        <li>
          <span class="label">营业执照号：</span>
          <el-input v-model="insuredData.businessLicence"></el-input>
        </li>
      </ul>

      <ul class="form right">
        <li class="empty">
          <el-button></el-button>
        </li>
        <li>
          <el-button type="primary" size="mini" icon="el-icon-caret-right" @click="result">客户重置</el-button>
        </li>
        <li>
          <el-button type="primary" size="mini" icon="el-icon-caret-right" @click="confirm">客户确认</el-button>
        </li>
        <li>
          <el-button type="primary" size="mini" icon="el-icon-caret-right" @click="open = true">查询客户</el-button>
        </li>
        <li>
          <el-button type="primary" size="mini" icon="el-icon-caret-right">同投保人</el-button>
        </li>
      </ul>
    </section>
    <Sel v-if="modal" :visible.sync="open" @close="close"></Sel>
  </Fold>
</template>

<script>
  import { mapGetters, mapMutations, } from 'vuex'
  import Fold from 'utils/fold/fold'
  import Sel from 'utils/selectUser/sel'
  export default {
    name: "insured",
    components: {
      Fold,
      Sel,
    },
    data() {
      return {
        showInsured: true,
        modal: true,
        open: false,

        /* 地址拼接展示数据 */
        countrySplic: '',
        // provinceSplic: '',
        citySplic: '',
        // areaSplic: '',
        streetSplic: '',

        insuredData: {},

        country: [],
        city: [],
        selectCountry: [],
        props: {
          value: 'name',
          label: 'name',
          children: 'children',
        }
      }
    },

    watch: {      
      '$route' (to, from) {
        if(to.name === '客户视图') {
          this.modal = false
        } else if(from.name === '客户视图') {
          this.modal = true
        }
      }
    },

    computed: {
      ...mapGetters([
        'getInsured',
        'getSelectData',
        'getCountry',
        'getCity',
      ])
    },

    methods: {
      /* 客户确认 */
      confirm() {
        this.formData(this.insuredData)
      },

      /* 客户重置 */
      async result() {
        try {
          await this.$confirm('是否清除原有数据，重新添加新客户？', '重置', {
            confirmButtonText: '重置',
            cancelButtonText: '取消',
            type: 'warning'
          })

          this.insuredData.userCode = ''
          this.insuredData.userName = ''
          this.insuredData.naturePolicyholder = ''
          this.insuredData.certificatesType = ''
          this.insuredData.certificatesCode = ''
          this.insuredData.effective = ''
          this.insuredData.occupation = ''
          this.insuredData.sex = ''
          this.insuredData.shareholderUser = 1
          this.insuredData.country = ''
          // this.insuredData.province = ''
          // this.insuredData.city = ''
          // this.insuredData.area = ''
          this.insuredData.street = ''
          this.insuredData.address = ''
          this.insuredData.zipCode = ''
          this.insuredData.level = ''
          this.insuredData.reason = ''
          this.insuredData.managingContacts = ''
          this.insuredData.unitProperties = ''
          this.insuredData.agentCard = ''
          this.insuredData.agentCardDate = ''
          this.insuredData.fixedTelephone = ''
          this.insuredData.moveTelephone = ''
          this.insuredData.fax = ''
          this.insuredData.legalRepresentative = ''
          this.insuredData.legalRepresentativeCode = ''
          this.insuredData.legalRepresentativeDate = ''
          this.insuredData.organizationCodeCertificate = ''
          this.insuredData.taxRegistrationCertificate = ''
          this.insuredData.businessLicence = ''
          this.selectCountry = []

          // 清空数据后传递给Mutations
          this.formData(this.insuredData)
        } catch (err) {
          this.$message({
            type: 'warning',
            message: '已取消重置',
          })
        }
      },

      /* 验证证件号码是否为number */
      zipCode(num) {
        /* 判断输入是否为数字 */
        const flag = /^[0-9]*$/u.test(num)
        if (!flag && num !== undefined) {
          alert('邮编只能输入数字', num)
          this.insuredData.zipCode = ''
        }
      },

      /* 处理地址格式 */
      address(val) {
        val === '中国' ? this.city = this.getCity : this.city = []
        this.countrySplic = val
        this.citySplic = ''
        this.selectCountry = []
        let reg = this.selectCountry.join('')
        this.insuredData.address = `${this.countrySplic}${reg}${this.streetSplic}`
      },

      region(val) {
        this.citySplic = val.join('')
        this.insuredData.address = `${this.countrySplic}${this.citySplic}${this.streetSplic}`
      },

      street(val) {
        let reg = this.selectCountry.join('')
        this.streetSplic = val
        this.insuredData.address = `${this.countrySplic}${reg}${this.streetSplic}`
      },
      /* 处理地址格式 */

      close() {
        this.open = false
      },

      ...mapMutations({
        formData: 'SET_INSURED_DATA'
      })
    },

    created() {
      let { ...tplData } = this.getInsured
      this.insuredData = tplData
      
      this.city = this.getCity
      this.countrySplic = '中国'
      this.insuredData.country = '中国'
    },
  }
</script>

<style scoped>
  .empty {
    visibility: hidden;
  }

  .btn {
    float: right;
  }

  .ml5 {
    left: 0;
    margin-top: 4px;
    margin-left: 8px;
  }

  .right :nth-child(n+2) {
    float: right;
  }

  .text {
    margin: 0 10px;
    color: #000;
  }
</style>