<template>
    <Fold Name="账户信息" @switch-form="showAccount = !showAccount">
    <section v-if="showAccount" class="formAccount">
      <ul class="form">
        <li>
          <span class="label">收款人账号：</span>
          <el-input></el-input>
        </li>
        <li>
          <span class="label">收款人户名：</span>
          <el-input></el-input>
        </li>
        <li>
          <span class="label">收款银行大类：</span>
          <el-input></el-input>
        </li>
        <li>
          <span class="label">开户行省：</span>
          <el-input></el-input>
        </li>
        <li>
          <span class="label">开户行市：</span>
          <el-input></el-input>
        </li>
        <li>
          <span class="label">开户行县：</span>
          <el-input></el-input>
        </li>
        <li>
          <span class="label">开户行：</span>
          <el-input></el-input>
        </li>
        <li>
          <span class="label">银行网点：</span>
          <el-input></el-input>
        </li>
        <li>
          <span class="label">CNAPS号：</span>
          <el-input></el-input>
        </li>
        <li>
          <span class="label">开户行地址：</span>
          <el-input></el-input>
        </li>
        <li>
          <span class="label">对公对私：</span>
          <el-select v-model="PTP">
            <el-option v-for="item in PTPArr" :value="item.value" :label="item.name" :key="item.key"></el-option>
          </el-select>
        </li>
      </ul>
    </section>
  </Fold>
</template>

<script>
import Fold from 'utils/fold/fold'
export default {
  name: "account",

  components: {
    Fold,
  },

  data() {
    return {
      showAccount: true,

      PTP: '',
      PTPArr: [
        { name: '请选择', value: '', key: 0 },
        { name: '对公', value: 1, key: 1 },
        { name: '对私', value: 2, key: 2 },
      ]
    }
  },
}
</script>

<style scoped>
  .formAccount {
    height: 100%;
  }
  .container .form li {
    float: none;
  }
  .text {
    margin: 0 10px;
    color: #666;
  }
</style>