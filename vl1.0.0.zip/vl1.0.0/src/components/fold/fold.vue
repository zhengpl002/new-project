<!-- 表单展开组件 
    1.  @switch-form      控制展开状态    [Boolean]
    2.  Name              表单名字        [String]
-->


<template>
  <article class="sec">
    <div class="Switch" @click="switchForm">
      <span v-if="!open"><i class="el-icon-plus"></i></span>
      <span v-else-if="open"><i class="el-icon-minus"></i></span>
      <span class="text">{{ Name }}</span>
    </div>
    <slot/>
  </article>
</template>

<script>
export default {
  name: "fold",
  props: {
    Name: {
      type: String,
      default: ''
    },
  },

  data() {
    return {
      open: true,
    }
  },

  methods: {
    switchForm() {
      this.open = !this.open
      this.$emit('switch-form')
    }
  },
}
</script>

<style scoped>
  .sec {
    height: 100%;
    position: relative;
    /* margin: 10px 15px 30px 15px; */
    padding: 0 0 5px 0;
    border-bottom: 1px solid #ddd;
  }
  .sec:last-child {
    border-bottom: none;
  }
  .Switch {
    padding: 0 10px 0 10px;
    font-weight: bold;
    line-height: 40px;
    background-color: #FAFAFA;
    border-bottom: 1px solid #ddd;
    margin-bottom: 10px;
    cursor: pointer;
  }
  .text {
    margin: 0 10px;
    color: #666;
  }
  i {
    color: #409EFF;
    font-weight: bold;
  }
</style>