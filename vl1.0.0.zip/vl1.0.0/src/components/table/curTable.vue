<template>
  <el-table :data="data">
    <el-table-column></el-table-column>
  </el-table>
</template>

<script>
  export default {
    name: "curTable",
  
    props: {
      data: {
        type: Array,
        default: () => []
      },
    },
    data() {
      return {
      }
    },

  }
</script>

<style lang="less" scoped>

</style>