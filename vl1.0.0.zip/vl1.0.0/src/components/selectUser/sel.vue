<!-- 表单展开组件 
    1.  visible           控制展开状态    [Boolean]
    2.  close             关闭弹窗时触发  [Function]
-->

<template>
  <!-- 弹窗 -->
  <el-dialog title="选择客户" :visible="visible" width="1100px" @close="close">
    <Fold Name="客户信息" @switch-form="dialogForm = !dialogForm" class="bgFold">
      <!-- 弹窗表单 -->
      <div v-if="dialogForm">
        <ul class="form">
          <li>
            <span class="label dialog"><i class="red">*</i>客户类型：</span>
            <el-select v-model="dialogUserType">
              <el-option v-for="item in Data.naturePolicy" :value="item.value" :label="item.name" :key="item.key"></el-option>
            </el-select>
          </li>
          <li>
            <span class="label dialog">客户名称：</span>
            <el-input v-model="dialogUserName"></el-input>
          </li>
        </ul>
        <ul class="form">
          <li>
            <span class="label dialog">证件类型：</span>
            <el-select v-model="dialogCardType">
              <el-option v-for="item in Data.certificates" :value="item.value" :label="item.name" :key="item.key"></el-option>
            </el-select>
          </li>
          <li>
            <span class="label dialog">证件号码：</span>
            <el-input v-model="dialogCardNum"></el-input>
          </li>
        </ul>
        <ul class="form right">
          <li></li>
          <li>
            <el-button-group>
              <el-button type="primary" size="mini" icon="el-icon-search" round></el-button>
              <el-button type="primary" size="mini" icon="el-icon-refresh" round></el-button>
            </el-button-group>
          </li>
        </ul>
      </div>
    </Fold>

    <!-- 弹窗表格 -->
    <el-table border :data="tableData">
      <el-table-column sortable label="个人法人性质" prop=""></el-table-column>
      <el-table-column sortable label="客户名称" prop="Name"></el-table-column>
      <el-table-column sortable label="客户层级" prop="Level"></el-table-column>
      <el-table-column sortable label="证件类型" prop="Card"></el-table-column>
      <el-table-column sortable label="证件号码" prop="Code"></el-table-column>
      <el-table-column sortable label="通用地址" prop="Address"></el-table-column>
      <el-table-column sortable label="邮编" prop=""></el-table-column>
    </el-table>

    <el-pagination class="center" @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="pageNumber"
      :page-sizes="[10, 20, 30, 50]" :page-size="pageSize" layout="total, sizes, prev, pager, next, jumper" :total="5">
    </el-pagination>
    
    <ul class="form right">
      <li class="empty">
        <el-button></el-button>
      </li>
      <li>
        <el-button type="primary" size="mini" icon="el-icon-caret-right">返回</el-button>
      </li>
      <li>
        <el-button type="primary" size="mini" icon="el-icon-caret-right">确定</el-button>
      </li>
      <li>
        <el-button type="primary" size="mini" icon="el-icon-caret-right" @click="userView">客户视图</el-button>
      </li>
    </ul>
  </el-dialog>
</template>

<script>
  import { mapGetters } from 'vuex'
  import Fold from 'utils/fold/fold'
  export default {
    name: "Sel",

    props: {
      visible: {
        required: true,
        type: Boolean,
        default: false,
      },
    },

    components: {
      Fold,
    },

    data() {
      return {
        pageNumber: 1,
        pageSize: 10,

        tableData: [
          { Name: '黄某', Level: 'Level 1', Card: '身份证', Code: '123', Address: '四窜' },
          { Name: '张某', Level: 'Level 2', Card: '护照', Code: '456', Address: '弗建省' },
          { Name: '胡某', Level: 'Level 3', Card: '地铁卡', Code: '789', Address: '广Door' },
          { Name: '吴某', Level: 'Level 4', Card: '公交卡', Code: '000', Address: '西藏' },
          { Name: '李某', Level: 'Level 5', Card: '没卡', Code: '10', Address: '拉萨' },
        ],

        /* 弹窗数据 */
        // selectCustomers: false,
        dialogForm: true,
        dialogUserType: '',
        dialogUserName: '',
        dialogCardType: '',
        dialogCardNum: '',

        Data: {},
      }
    },

    computed: {
      ...mapGetters([
        'getApplicant'
      ])
    },

    methods: {
      /* 客户视图 */
      userView() {
        this.$router.push({
          path: '/insure/added/userView',
          query: {
            id: 1,
          },
        })
      },

      /* 关闭弹窗时触发 */
      close() {
        this.$emit('close', false)
      },

      /* 分页处理 */
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`);
      },
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`);
      },
    },

    created() { 
      let { ...tplData } = this.getApplicant
      this.Data = tplData
    },

  }
</script>

<style lang="css" scoped>
  .el-dialog__body>.sec {
    margin: 10px 0 30px 0 !important;
  }

  .bgFold >>> .Switch {
    background-color: #FFF;
  }

  .dialog {
    margin-top: 0;
  }

  .right :nth-child(n+2) {
    float: right;
  }

  .empty {
    visibility: hidden;
  }
</style>

<!-- <style>
  .el-dialog__header {
    background-color: #CCC;
  }
</style> -->