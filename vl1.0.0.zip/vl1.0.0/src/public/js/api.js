import { checkResp, handleErr, ajax } from '../../axios/ajax'

export { checkResp, handleErr }

const sysURL = ''

/* 测试API */
export const get_list = params =>
    ajax.get('/product/list', { params })
        .then(res => checkResp(res))