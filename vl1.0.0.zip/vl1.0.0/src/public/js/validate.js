/* 合法uri*/
export function validateURL(textval) {
    const urlregex = /^(https?|ftp):\/\/([a-zA-Z0-9.-]+(:[a-zA-Z0-9.&%$-]+)*@)*((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]?)(\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])){3}|([a-zA-Z0-9-]+\.)*[a-zA-Z0-9-]+\.(com|edu|gov|int|mil|net|org|biz|arpa|info|name|pro|aero|coop|museum|[a-zA-Z]{2}))(:[0-9]+)*(\/($|[a-zA-Z0-9.,?'\\+&%$#=~_-]+))*$/;
    return urlregex.test(textval);
}

/* 小写字母*/
export function validateLowerCase(str) {
    const reg = /^[a-z]+$/;
    return reg.test(str);
}

/* 大写字母*/
export function validateUpperCase(str) {
    const reg = /^[A-Z]+$/;
    return reg.test(str);
}

/* 大小写字母*/
export function validatAlphabets(str) {
    const reg = /^[A-Za-z]+$/;
    return reg.test(str);
}

export function isEmpty(value) {
    if (value == null || typeof(value) === "undefined") {
        return true;
    }
    if (typeof(value) === "string" && value == "") {
        return true;
    }
    if (typeof(value) === "object") {
        for (var i in value) {
            if (value.hasOwnProperty(i)) {
                return false;
            }
        }
        return true;
    }
    return false;
}

export function isNumber(value) {
    if (typeof(value) !== "undefined" && typeof(value) === "number") {
        return true;
    }
    return false;
}

export function isNotEmpty(value) {
    return !this.isEmpty(value);
}

export function isQQ(qq) {
    if (this.isEmpty(qq)) {
        return false;
    }
    return /^[1-9]\d{4,11}$/.test(qq);
}

/**
 * 检查是否是非数值，而且小数只能保留6位
 * @param    value 需要检查格式的值
 * @return    {"result":检查结果,"value":格式化后的值}
 */
export function isNumAndFormat(value, fixed) {
    //检查是否是非数字值
    if (this.isEmpty(value)) {
        value = "";
        return {
            "result": false,
            "value": value
        };
    }
    if (isNaN(value)) {
        value = "";
        return {
            "result": false,
            "value": value
        };
    }
    fixed = (this.isEmpty(fixed)) ? 2 : fixed;
    //检查小数点后是否多余于fixed位
    if (value.toString().split(".").length > 1 && value.toString().split(".")[1].length > fixed) {
        value = Number(value).toFixed(fixed);
        return {
            "result": false,
            "value": value
        };
    }
    return {
        "result": true,
        "value": value
    };
}

/**
 * @param obj  html  input对象
 */
export function numFormat(obj, fixed) {
    var returnObj = this.isNumAndFormat(obj.value, fixed);
    obj.value = returnObj.value;
}

/**
 * 验证是否是手机号
 * @param    phoneNum 需要验证的值
 * @return    true 是手机号码格式
 *            false 不是手机号码格式
 */
export function isMobile(phoneNum) {
    if (phoneNum) {
        if (phoneNum.length == 0) {
            return '手机号码不能为空';
        } else if (phoneNum.length != 11) {
            return '手机号码长度不对';
        } else if (!(/^1[34578]\d{9}$/.test(phoneNum))) {
            return '手机号码有误，请重填';
        } else
            return "true";
    } else {
        return '手机号码不能为空';
    }
}

export function isEmail(value) {
    if (value == null || typeof(value) == "undefined" || value == "") {
        return false;
    }
    var reg = /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/;
    if (!reg.test(value)) {
        return false;
    }
    return true;
}

//身份证号码校验
export function isIdcard(idcard) {
    return /^((1[1-5])|(2[1-3])|(3[1-7])|(4[1-6])|(5[0-4])|(6[1-5]))(\d{13}|\d{16}|(\d{15}[x|X]))$/.test(idcard);
}

export function isNotMobile(value) {
    return !this.isMobile(value);
}

// 加权因子
var wi = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2, 1];
// 身份证验证位值.10代表X
var valideCodeArr = [1, 0, 10, 9, 8, 7, 6, 5, 4, 3, 2];
var areaMap = {
    11: "北京",
    12: "天津",
    13: "河北",
    14: "山西",
    15: "内蒙古",
    21: "辽宁",
    22: "吉林",
    23: "黑龙江",
    31: "上海",
    32: "江苏",
    33: "浙江",
    34: "安徽",
    35: "福建",
    36: "江西",
    37: "山东",
    41: "河南",
    42: "湖北",
    43: "湖南",
    44: "广东",
    45: "广西",
    46: "海南",
    50: "重庆",
    51: "四川",
    52: "贵州",
    53: "云南",
    54: "西藏",
    61: "陕西",
    62: "甘肃",
    63: "青海",
    64: "宁夏",
    65: "新疆",
    71: "台湾",
    81: "香港",
    82: "澳门",
    91: "国外"
};
// 男女ID
var sexMap = {0: "女", 1: "男"};
//错误信息
var status = ["true", "身份证号码位数不对!", "身份证号码出生日期超出范围或含有非法字符!", "身份证号码校验错误!", "身份证地区非法!"];

//去掉字符串头尾空格
export function trim(str) {
    return str.replace(/(^\s*)|(\s*$)/g, "");
}

/**
 * 验证身份证号码中的生日是否是有效生日
 * @param idCard 身份证字符串
 * @return
 */
export function checkBrith(idCard) {
    var result = true;
    if (15 == idCard.length) {
        var year = idCard.substring(6, 8);
        var month = idCard.substring(8, 10);
        var day = idCard.substring(10, 12);
        var temp_date = new Date(year, parseFloat(month) - 1, parseFloat(day));

        // 对于老身份证中的年龄则不需考虑千年虫问题而使用getYear()方法
        if (temp_date.getYear() != parseFloat(year) || temp_date.getMonth() != parseFloat(month) - 1 || temp_date.getDate() != parseFloat(day)) {
            result = false;
        }
    } else if (18 == idCard.length) {
        var year = idCard.substring(6, 10);
        var month = idCard.substring(10, 12);
        var day = idCard.substring(12, 14);
        var temp_date = new Date(year, parseFloat(month) - 1, parseFloat(day));

        // 这里用getFullYear()获取年份，避免千年虫问题
        if (temp_date.getFullYear() != parseFloat(year) || temp_date.getMonth() != parseFloat(month) - 1 || temp_date.getDate() != parseFloat(day)) {
            result = false;
        }
    } else {
        result = false;
    }

    return result;
}

//身份证开头2位数字校验
export function checkArea(idCard) {
    if (areaMap[parseInt(idCard.substr(0, 2))] == null) {
        return false;
    } else {
        return true;
    }
}

/**
 * 判断身份证号码为18位时最后的验证位是否正确
 * @param idCardArr 身份证号码数组
 * @return
 */
export function check18Code(idCardArr) {
    var sum = 0; // 声明加权求和变量
    var idCardArr = idCardArr.split("");
    if (idCardArr[17].toLowerCase() == 'x') {
        idCardArr[17] = 10;// 将最后位为x的验证码替换为10方便后续操作*/

    }
    for (var i = 0; i < 17; i++) {
        sum += wi[i] * idCardArr[i];// 加权求和
    }
    var valCodePosition = sum % 11;// 得到验证码所位置
    if (idCardArr[17] == valideCodeArr[valCodePosition]) {
        return true;
    } else {
        return false;
    }
}

//身份证校验（15或者18位）
export function checkIdCard(idCard) {
    //去掉首尾空格
    idCard = trim(idCard.replace(/ /g, ""));
    if (idCard.length == 15 || idCard.length == 18) {
        if (!checkArea(idCard)) {
            return status[4];
        } else if (!checkBrith(idCard)) {
            return status[2];
        } else if (idCard.length == 18 && !check18Code(idCard)) {
            return status[3];
        } else {
            return status[0];
        }
    } else {
        //不是15或者18，位数不对
        return status[1];
    }
}

/**
 * 通过身份证得到性别
 * @param idCard 正确的15/18位身份证号码
 * @return 女、男
 */
export function getSex(idCard) {
    if (idCard.length == 15) {
        return sexMap[idCard.substring(14, 15) % 2];
    } else if (idCard.length == 18) {
        return sexMap[idCard.substring(14, 17) % 2];
    } else {
        //不是15或者18,null
        return null;
    }
}

/**
 * 得到生日"yyyy-mm-dd"
 * @param {Object} idCard 正确的15/18位身份证号码
 */
export function getBirthday(idCard) {
    var birthdayStr;
    if (15 == idCard.length) {
        birthdayStr = idCard.charAt(6) + idCard.charAt(7);
        if (parseInt(birthdayStr) < 10) {
            birthdayStr = '20' + birthdayStr;
        } else {
            birthdayStr = '19' + birthdayStr;
        }
        birthdayStr = birthdayStr + '-' + idCard.charAt(8) + idCard.charAt(9) + '-' + idCard.charAt(10) + idCard.charAt(11);
    } else if (18 == idCard.length) {
        birthdayStr = idCard.charAt(6) + idCard.charAt(7) + idCard.charAt(8) + idCard.charAt(9) + '-' + idCard.charAt(10) + idCard.charAt(11) + '-' + idCard.charAt(12) + idCard.charAt(13);
    }

    return birthdayStr;
}

export function addZero(value) {
    return (value < 10 ? "0" + value : value)
}

export function isBankCard(value, Toast) {
    if (!value) {
        return '请填写银行卡号';
    }
    if (value.length < 16 || value.length > 19) {
        return '银行卡号长度必须在16到19之间';
    }
    var num = /^\d*$/; //全数字
    if (!num.exec(value)) {
        return '银行卡号必须全为数字';
    }
    var strBin = "10,18,30,35,37,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,58,60,62,65,68,69,84,87,88,94,95,98,99";
    if (strBin.indexOf(value.substring(0, 2)) == -1) {
        return '银行卡号开头6位不符合规范';
    }
    return true;

    function layer(msg) {
        Toast({
            message: msg,
            position: 'center',
            duration: 2000
        });
    }
}

export function isInputOk(value, Toast, msg) {
    if (typeof (value) === 'undefined') {
        Toast({
            message: msg,
            position: 'center',
            duration: 2000
        });
        return false;
    }
    return true;
}

export function getDaysCount(s1, s2) {
    var days = s2.getTime() - s1.getTime();
    var time = parseInt(days / (1000 * 60 * 60 * 24));
    return time;
}

//根据出生年月获取年龄
export function getAgeFromBirthday(strBirthday, beginTime) {
    var returnAge;
    var strBirthdayArr = strBirthday.split("-");
    var birthYear = strBirthdayArr[0];
    var birthMonth = strBirthdayArr[1];
    var birthDay = strBirthdayArr[2];
    // var  d = new Date();
    var strBeginTime = beginTime.split("-");
    var nowYear = strBeginTime[0];
    var nowMonth = strBeginTime[1];
    var nowDay = strBeginTime[2];
    if (nowYear == birthYear) {
        returnAge = 0;//同年 则为0岁
    }
    else {
        var ageDiff = nowYear - birthYear; //年之差
        if (ageDiff > 0) {
            if (nowMonth == birthMonth) {
                var dayDiff = nowDay - birthDay;//日之差
                if (dayDiff < 0) {
                    returnAge = ageDiff - 1;
                }
                else {
                    returnAge = ageDiff;
                }
            }
            else {
                var monthDiff = nowMonth - birthMonth;//月之差
                if (monthDiff < 0) {
                    returnAge = ageDiff - 1;
                }
                else {
                    returnAge = ageDiff;
                }
            }
        }
        else {
            returnAge = -1;//返回-1 表示出生日期输入错误 晚于今天
        }
    }
    return returnAge;//返回周岁年龄
}

//时间控件(minAge最小周岁，maxAge）
export function getTimeStarAndEnd(minAge, maxAge) {
    const date = new Date();
    const year = date.getFullYear();
    const month = date.getMonth() + 1;
    const day = date.getDate();
    //18
    /*开始年龄*/
    const startDate = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + (date.getDate() + 1);
    /*结束年龄*/
    const endDate = (date.getFullYear() - 18) + "-" + (date.getMonth() + 1) + "-" + date.getDate();
    /*显示年龄*/
    const showDate = (year - 30) + "-" + month + "-" + day;
    return {startDate: startDate, endDate: endDate, showDate: showDate}
}

/*获取X周岁
*strBirthday yy-mm-dd出生日期
*beginTime yy-mm-dd,比较的日期，一般是保险起期
*/
export function getRealAge(strBirthday, beginTime) {
    var returnAge;
    var strBirthdayArr = strBirthday.split("-");
    var birthYear = strBirthdayArr[0];
    var birthMonth = strBirthdayArr[1];
    var birthDay = strBirthdayArr[2];
    // var  d = new Date();
    var strBeginTime = beginTime.split("-");
    var nowYear = strBeginTime[0];
    var nowMonth = strBeginTime[1];
    var nowDay = strBeginTime[2];
    if (nowYear == birthYear) {
        returnAge = 0;//同年 则为0岁
    }
    else {
        var ageDiff = nowYear - birthYear; //年之差
        if (ageDiff > 0) {
            if (nowMonth == birthMonth) {
                var dayDiff = nowDay - birthDay;//日之差
                if (dayDiff < 0) {
                    returnAge = ageDiff - 1;
                }
                else {
                    returnAge = ageDiff;
                }
            }
            else {
                var monthDiff = nowMonth - birthMonth;//月之差
                if (monthDiff < 0) {
                    returnAge = ageDiff - 1;
                }
                else {
                    returnAge = ageDiff;
                }
            }
        }
        else {
            returnAge = -1;//返回-1 表示出生日期输入错误 晚于今天
        }
    }
    return returnAge;//返回周岁年龄
}

