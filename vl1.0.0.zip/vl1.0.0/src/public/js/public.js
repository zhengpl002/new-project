/*扁平化数组转机构树*/
export function toTreeData(data, depid) {
    var pos = {};
    var tree = [];
    var i = 0;
    let cSnrdpt = '';
    for(let j=0,len=data.length;j<len;j++){
         let item=data[j];
        if(depid==item.cDptcde){
                  cSnrdpt=item.cSnrdpt;
                  break;
              }
       }
   /* while (data.length) {

        if (cSnrdpt == data[i].cSnrdpt) {
            tree.push({
                father: data[i].cSnrdpt,
                name: data[i].cDptcnm,
                id: data[i].cDptcde,
                children: [],
            });
            pos[data[i].cDptcde] = [tree.length - 1];
            data.splice(i, 1);
            i--;
        } else {
            var posArr = pos[data[i].cSnrdpt];
            if (posArr != undefined) {
                var obj = tree[posArr[0]];
                for (let j = 1; j < posArr.length; j++) {
                    obj = obj.children[posArr[j]];
                }
                obj.children.push({
                    id: data[i].cDptcde,
                    name: data[i].cDptcnm,
                    father: data[i].cSnrdpt,
                    children: [],
                });
                pos[data[i].cDptcde] = posArr.concat([obj.children.length - 1]);
                data.splice(i, 1);
                i--;
            }
        }
        i++;
        if (i > data.length - 1) {
            i = 0;
        }
    }*/
    while (data.length) {
        let item=data[i];
        if (cSnrdpt == item.cSnrdpt) {
            tree.push({
                father: item.cSnrdpt,
                name: `${item.cDptcde}_${item.cDptcnm}`,
                id: item.cDptcde,
                children: [],
            });
            pos[item.cDptcde] = [tree.length - 1];
            data.splice(i, 1);
            i--;
        } else {
            var posArr = pos[item.cSnrdpt];
            if (posArr != undefined) {
                var obj = tree[posArr[0]];
                for (let j = 1; j < posArr.length; j++) {
                    obj = obj.children[posArr[j]];
                }
                obj.children.push({
                    id: item.cDptcde,
                    name: `${item.cDptcde}_${item.cDptcnm}`,
                    father: item.cSnrdpt,
                    children: [],
                });
                pos[item.cDptcde] = posArr.concat([obj.children.length - 1]);
                data.splice(i, 1);
                i--;
            }
        }
        i++;
        if (i > data.length - 1) {
            i = 0;
        }
    }

    return tree;
}

/*手机号码校验*/

export function addzero(val) {
    return (val < 10 ? "0" + val : val)
}

/*过滤成2位小数*/

export function formatTwoDecimal(val) {
    return Number(val).toFixed(2);
}

/*转%*/

export  function  formatPercentage(value,rate) {
    if(value==null){
        return null;
    }
    const val=Number(value);
    if (typeof(val) !== "undefined" && typeof(val) === "number") {
        return  val*rate;
    }
    return '';
    
}

export function treeify(data) {
        var disposable = {}, top, item;
        for (let index in data) {
            item = data[index];
            if (!(item.id in disposable)) {
                disposable[item.id] = [];
            }
            if (!(item.parentId in disposable)) {
                disposable[item.parentId] = [];
            }
            item.children = disposable[item.id];
            if (item.parentId) {
                disposable[item.parentId].push(item);
            } else {
                top = item;
            }
        }
        return top;
}
    /*时间戳转年月日*/
export function formatTimestamp(val) {
    if (!val || '' == val || null == val) return '';
    const v = parseInt(val);
    const date = new Date(v);
    return (`${date.getFullYear()}-${addzero(date.getMonth() + 1)}-${addzero(date.getDate())}`);

}

/*数组遍历时间戳转年月日*/
export function arrDataFormat(arr, item) {
    if (!arr.length) return arr;
    arr.forEach(function (v, i) {
        v[item] = formatTimestamp(v[item]);
    })
    return arr;

}

/*判断是否为中文*/
export function isChinese(val) {
    var pattern = /^[\u4e00-\u9fa5]*$/;
    if (!pattern.test(val)) {
        return '必须为中文'
    } else {
        return true;
    }
}

export function FormatToTimestamp(val) {
    return new Date(val).getTime();

}

/*判断是否含有小数*/
export function checkDecimal(c) {
    var r = /^[+-]?[1-9]?[0-9]*\.[0-9]*$/;
    return r.test(c);
}

export function formateTime(t) {
    const date = new Date(t);
    return `${date.getFullYear()}年${addzero(date.getMonth() + 1)}月${addzero(date.getDate())}日 ${addzero(date.getHours())}:${addzero(date.getMinutes())}:${addzero(date.getSeconds())}`

}

export function isNull(val) {
    const title=val||'';
    return title

}
/*判断是否含有中文*/
export function checkChinese(str) {
    if (escape(str).indexOf('%u') != -1) {
        return true;
    }
    else {
        return false;
    }
}

export function formatDate(val) {
    if (!val || '' == val || null == val) return '';
    const v = parseInt(val);
    const date = new Date(v);
    return (`${date.getFullYear()}-${addzero(date.getMonth() + 1)}-${addzero(date.getDate())}`);
}

export function formatTimestamp1(val) {
    const date = new Date(val)
    return (`${date.getFullYear()}-${addzero(date.getMonth() + 1)}-${addzero(date.getDate())}`)
}