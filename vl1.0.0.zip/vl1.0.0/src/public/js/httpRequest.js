import $http from './../../axios/API';
import { Message } from 'element-ui';

const sysURL='';

/*投保向导-获取获取机构*/
export function getDeptTree(data,success) {
    const url=`${sysURL}/deptInfo/getDeptTree`;
    const callback=function (res) {
        if(1==res.resultCode){
            success&&success(res);
        }else{
            Message.warning(res.resultMsg)
        }

    }
    $http.post(url,data,callback)
}

/*投保向导-获取产品明细*/
export function getProduct(data,success) {
    const url=`${sysURL}/policy-entering/v1/product/detail`;
    const callback=function (res) {
        if(1==res.resultCode){
            success&&success(res);
        }else{
            Message.warning(res.resultMsg)
        }

    }
    $http.get(url,data,callback)
}
/*投保向导-确认提交*/

  export function tempConfirm(data,success) {
    const url=`${sysURL}/deptInfo/tempSaveDeptInfo`;
    const callback=function (res) {
        if(1==res.resultCode){
            // Message.success('保存成功')
            success&&success(res);
        }else{
            Message.warning(res.resultMsg)
        }

    }
    $http.post(url,data,callback)
}
