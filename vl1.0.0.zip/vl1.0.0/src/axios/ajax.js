import * as Axios from 'axios'
import { Message } from 'element-ui'

/* 默认请求地址 */
let baseURL= process.env.API_ROOT
console.log(baseURL)
// let baseURL = './policy-entering/v1'

/* 检查API响应情况 */
const checkRespones = res => {
  // console.log('API响应', res)

  const code = res.data.resultCode
  if(code == 1) {
    return Promise.resolve(res)
  }
  // if(code === 0) {
  //   return Promise.resolve(res)
  // }

  const error = new Error()
  error.code = code
  error.msg = res.data.resultMsg || 'API并不想响应你,并向你抛出一个错误！'
  return Promise.reject(error)
}

const handleError = function(err) {
  const msg = err.msg || '未知'
  if(err.code > 0) {
    Message({
      type: 'warning',
      message: `服户端：${msg}`
    })
  } else {
    Message({
      type: 'warning',
      message: `客户端：${msg}`
    })
  }
}

/* axios请求控制器初始化 */
let controller = null

/* 停止回调 */
const stopCallback = function(cancel) {
  controller = cancel
}

/* axios实例 */
const instance = Axios.create({
  /* 请求方式 */
  methods: 'post',

  /* API地址 */
  baseURL: baseURL,

  /* 请求超时 */
  timeout: 60000,

  /* 请求格式 */
  contentType: 'application/json;charset=UTF-8;',

  /* 请求格式 */
  responseType: 'json',

  /* 请求头部 */
  // headers: {
  //   post: {
  //     'Content-Type': 'application/json',
  //     'x-requested-with': 'XMLHttpRequest',
  //     // 'Access-Control-Allow-Origin':'*',
  //     /* 文件上传 */
  //     // 'Content-Type': 'multipart/form-data'
  //   },
  //   get: {
  //     'x-requested-with': 'XMLHttpRequest'
  //   }
  // },

  cancelToken: new Axios.CancelToken(stopCallback)
})

/* 停止回调方法关联到axios实例中 */
instance.cancel = function(message) {
  if(controller) {
    controller(message)
  }
}

/* 请求拦截器 */
instance.interceptors.request.use((req) => {
  // console.log('req', req)
  const Req = req || {}

  return Req
}, (err) => {
  Message.error('网络不仅出了问题,还向你抛出一个错误！')
  return Promise.reject(err)
})

/* 响应拦截器钩子 */
instance.interceptors.response.use((res) => {
  return checkRespones(res)
}, (err) => {
  console.error('err', err.response)
  Message.error('网络错误')
  return Promise.reject(err)
})

export const handleErr = handleError

export const checkResp = checkRespones

export const ajax = instance