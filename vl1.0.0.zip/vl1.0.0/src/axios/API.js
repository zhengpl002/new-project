    import axios from 'axios';
    import Es6Promise from 'es6-promise';
    import { Loading } from 'element-ui';
    import { Message } from 'element-ui';
    Es6Promise.polyfill();
    /*请求域名*/
    let baseURL = 'http://10.200.9.178:8763';
    // let baseURL= process.env.API_ROOT;
    axios.defaults.baseURL = baseURL;
    /*请求头*/
    axios.defaults.headers.post['Content-Type'] = 'application/json';

    axios.defaults.headers.post['x-requested-with'] = 'XMLHttpRequest';
    axios.defaults.headers.get['x-requested-with'] = 'XMLHttpRequest';
    /*请求超时时间*/
 /*   axios.defaults.timeout = 60000;*/
      /*请求拦截器*/
  /*  axios.interceptors.request.use(function (config) {
        return config;
    }, function (error) {
        loadingInstance.close();
        Message.warning('请求超时！');
        return Promise.reject(error);
    });*/

    
    /*响应拦截器*/
    axios.interceptors.response.use(function (response) {
        return response;
    }, function (error) {
        loadingInstance.close();
        Message.error('网络异常，请检查您的网络！');
        return Promise.reject(error);
    });

    const _get = function (url, params, callback) {
        const loadingInstance = Loading.service({ fullscreen: true });
        axios.get(url, {params})
            .then(function (response) {
                loadingInstance.close();
                if(9999==response.data.resultCode){
                    window.parent.location.href=response.data.resultMsg;
                }else{
                    callback&&callback(response.data);
                }

            })
            .catch(function (error) {
                loadingInstance.close();
                Message.error('网络异常，请检查您的网络！');
            });
    };

    const _post = function (url, data, callback) {
        const loadingInstance = Loading.service({ fullscreen: true });
        axios.post(url, data)
            .then(function (response) {
                loadingInstance.close();
                if(9999==response.data.resultCode){
                    window.parent.location.href=response.data.resultMsg;
                }else{
                    callback&&callback(response.data);
                }
            })
            .catch(function () {
                loadingInstance.close();
                Message.error('网络异常，请检查您的网络！');
            });
    };

    /*文件上传*/
    const _postFile = function (url, data, success, error) {
        const loadingInstance = Loading.service({ fullscreen: true });
        const config = {
            headers: {'Content-Type': 'multipart/form-data'}
        };
        axios.post(url, data, config)
            .then(function (response) {
                loadingInstance.close();
                if(9999==response.data.resultCode){
                    window.parent.location.href=response.data.resultMsg;
                }else{
                    success&&success(response.data);
                }
            })
            .catch(function (res) {
                loadingInstance.close();
                error && error(res);
                Message.error('网络异常，请检查您的网络！');
            });
    };
    const Api = {
        get: _get,
        post: _post,
        postFile: _postFile
    };
    export default Api;
