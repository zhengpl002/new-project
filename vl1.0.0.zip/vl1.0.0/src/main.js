import Vue from 'vue'
import App from './App'
import router from './router'
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import store from '../src/vuex/index';


// 引用API文件
import api from './axios/API'
// 将API方法绑定到全局,通过this.$http调用里面的方法
Vue.prototype.$http = api

Vue.use(ElementUI);

Vue.config.productionTip = false

new Vue({
    el: '#app',
    router,
    store,
    components: {App},
    template: '<App/>'
})
