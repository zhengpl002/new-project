var merge = require('webpack-merge')
var prodEnv = require('./prod.env')

module.exports = merge(prodEnv, {
  NODE_ENV: '"development"',
   //API_ROOT: '"http://10.200.9.112:8089"',//王泽峰台式
  API_ROOT: 'window.location.origin',
  // API_ROOT: '"http://10.128.18.83:8080"',//服务器DEV
   //API_ROOT: '"http://10.128.22.166:8080"',//服务器UAT
  //API_ROOT: '"http://10.200.8.183:8080"'//王涛
  //API_ROOT: '"http://10.200.9.108:8080"'//王泽峰Mac
  //API_ROOT: '"http://10.200.9.119:8088"'//何桂东
  //API_ROOT: '"http://10.200.9.114:8080"'//张永明
})
