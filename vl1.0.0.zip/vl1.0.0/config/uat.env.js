module.exports = {
  NODE_ENV: '"production"',
  API_ROOT: 'window.location.origin'
}
